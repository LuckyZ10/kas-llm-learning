"""
Integration Tests
=================

End-to-end tests for the complete DFT+ML+MD workflow.
These tests verify that all modules work together correctly.

Run with: pytest tests/test_integration.py -v
"""

import os
import sys
import json
import pytest
import numpy as np
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock, mock_open, call
from io import StringIO
import tempfile
import shutil


# =============================================================================
# Test Class: End-to-End Workflow Tests
# =============================================================================

@pytest.mark.integration
class TestEndToEndWorkflow:
    """Test suite for complete end-to-end workflows."""
    
    def test_dft_to_ml_to_md_workflow(self, tmp_path):
        """Test complete workflow: DFT → ML training → MD simulation."""
        from dft_to_lammps_bridge import DFTToLAMMPSBridge, VASPOUTCARParser
        from nep_training_pipeline import NEPTrainingPipeline
        
        working_dir = tmp_path / "workflow"
        working_dir.mkdir()
        
        # Create mock OUTCAR
        outcar = working_dir / "OUTCAR"
        outcar.write_text("""
FREE ENERGIE OF THE ION-ELECTRON SYSTEM
free  energy   TOTEN  =      -100.12345678 eV
POSITION                                       TOTAL-FORCE
  0.00000  0.00000  0.00000        0.001234    0.002345   -0.003456
  1.00000  0.00000  0.00000       -0.001234   -0.002345    0.003456
""")
        
        # Step 1: DFT parsing
        with patch('dft_to_lammps_bridge.read_vasp_out') as mock_read:
            mock_atoms = Mock()
            mock_atoms.get_chemical_symbols.return_value = ['Li', 'S']
            mock_atoms.get_positions.return_value = np.array([[0, 0, 0], [1, 0, 0]])
            mock_atoms.get_cell.return_value = np.eye(3) * 10
            mock_atoms.get_pbc.return_value = [True, True, True]
            mock_atoms.calc = Mock()
            mock_atoms.calc.get_potential_energy.return_value = -100.0
            mock_atoms.calc.get_forces.return_value = np.random.randn(2, 3) * 0.1
            
            mock_read.return_value = [mock_atoms]
            
            bridge = DFTToLAMMPSBridge(working_dir=str(working_dir / "bridge"))
            frames = bridge.parse_dft_output(outcar, code="vasp")
            
            assert len(frames) >= 0
    
    def test_structure_fetch_to_dft_pipeline(self, tmp_path):
        """Test pipeline: Structure fetching → DFT calculation."""
        try:
            from integrated_materials_workflow import (
                IntegratedWorkflowConfig, StructureFetcher, 
                ProgressMonitor, ErrorHandler
            )
            from pymatgen.core import Structure, Lattice
            
            working_dir = tmp_path / "pipeline"
            working_dir.mkdir()
            
            config = IntegratedWorkflowConfig(working_dir=str(working_dir))
            monitor = ProgressMonitor(total_stages=5)
            error_handler = ErrorHandler(config)
            
            # Create mock structure
            structure = Structure(
                lattice=Lattice.cubic(5.0),
                species=['Li', 'Cl'],
                coords=[[0, 0, 0], [0.5, 0.5, 0.5]]
            )
            
            # Mock structure fetcher
            fetcher = StructureFetcher(config.mp_config, monitor, error_handler)
            
            with patch.object(fetcher, 'fetch_from_mp') as mock_fetch:
                mock_fetch.return_value = [structure]
                
                structures = fetcher.fetch_from_mp(material_id="mp-1234")
                
                assert len(structures) == 1
                assert isinstance(structures[0], Structure)
        except ImportError:
            pytest.skip("Pymatgen not available")
    
    def test_ml_training_to_md_pipeline(self, tmp_path):
        """Test pipeline: ML training → MD simulation."""
        from nep_training_pipeline import NEPDataPreparer, NEPDataConfig
        from code_templates.md_simulation_lammps import LAMMPSConfig
        
        working_dir = tmp_path / "ml_md"
        working_dir.mkdir()
        
        # Create training data
        data_dir = working_dir / "data"
        data_dir.mkdir()
        
        xyz_content = """2
Lattice="10.0 0.0 0.0 0.0 10.0 0.0 0.0 0.0 10.0" Properties=species:S:1:pos:R:3:forces:R:3 energy=-50.0
Li 0.0 0.0 0.0 0.01 0.02 0.03
S 1.0 0.0 0.0 -0.01 -0.02 -0.03
"""
        (data_dir / "train.xyz").write_text(xyz_content)
        (data_dir / "test.xyz").write_text(xyz_content)
        
        # Test data preparation
        config = NEPDataConfig(type_map=['Li', 'S'])
        preparer = NEPDataPreparer(config)
        
        with patch.object(preparer, '_load_xyz') as mock_load:
            mock_load.return_value = [
                {
                    'atoms': Mock(),
                    'energy': -50.0,
                    'forces': np.random.randn(2, 3) * 0.1,
                    'symbols': ['Li', 'S']
                }
            ]
            
            train_xyz, test_xyz = preparer.prepare_dataset(working_dir / "output")
            
            assert Path(train_xyz).exists()
            assert Path(test_xyz).exists()
    
    def test_active_learning_workflow(self, tmp_path):
        """Test active learning workflow: explore → label → retrain."""
        try:
            from nep_training_pipeline import (
                NEPActiveLearning, NEPTrainer, 
                NEPTrainingConfig, NEPModelConfig
            )
            
            working_dir = tmp_path / "active_learning"
            working_dir.mkdir()
            
            config = NEPTrainingConfig(working_dir=str(working_dir))
            trainer = NEPTrainer(config)
            
            al = NEPActiveLearning(trainer, uncertainty_threshold=0.3)
            
            # Mock structure
            mock_structure = Mock()
            
            with patch.object(al, 'explore') as mock_explore:
                with patch.object(al, 'label') as mock_label:
                    mock_explore.return_value = [mock_structure]
                    mock_label.return_value = [
                        {'atoms': mock_structure, 'energy': -100.0, 'forces': np.zeros((6, 3))}
                    ]
                    
                    new_model = al.run_iteration("model.txt", mock_structure)
                    
                    assert mock_explore.called
                    assert mock_label.called
                    assert al.iteration == 1
        except ImportError:
            pytest.skip("Required modules not available")
    
    def test_battery_screening_pipeline(self, tmp_path):
        """Test battery material screening pipeline."""
        try:
            from battery_screening_pipeline import BatteryScreeningPipeline
            
            working_dir = tmp_path / "screening"
            
            pipeline = BatteryScreeningPipeline(
                material_ids=["mp-1234"],
                working_dir=str(working_dir)
            )
            
            assert pipeline.material_ids == ["mp-1234"]
            assert Path(pipeline.working_dir).exists()
        except ImportError:
            pytest.skip("battery_screening_pipeline not available")


# =============================================================================
# Test Class: Cross-Module Integration Tests
# =============================================================================

@pytest.mark.integration
class TestCrossModuleIntegration:
    """Test integration between different modules."""
    
    def test_dft_parser_to_ff_fitter(self, tmp_path, mock_outcar_content):
        """Test integration: DFT parser → Force field fitter."""
        from dft_to_lammps_bridge import VASPOUTCARParser, ForceFieldFitter, ForceFieldConfig
        
        working_dir = tmp_path / "dft_ff"
        working_dir.mkdir()
        
        # Parse DFT output
        parser = VASPOUTCARParser()
        outcar = working_dir / "OUTCAR"
        outcar.write_text(mock_outcar_content)
        
        with patch('dft_to_lammps_bridge.read_vasp_out') as mock_read:
            mock_atoms = Mock()
            mock_atoms.get_chemical_symbols.return_value = ['Li', 'S', 'P']
            mock_atoms.get_positions.return_value = np.random.randn(6, 3)
            mock_atoms.get_cell.return_value = np.eye(3) * 10
            mock_atoms.get_pbc.return_value = [True, True, True]
            mock_atoms.calc = Mock()
            mock_atoms.calc.get_potential_energy.return_value = -100.0
            mock_atoms.calc.get_forces.return_value = np.random.randn(6, 3) * 0.1
            
            mock_read.return_value = [mock_atoms]
            
            frames = parser.parse(outcar)
            
            # Transfer to fitter
            config = ForceFieldConfig(ff_type="buckingham", elements=['Li', 'S', 'P'])
            fitter = ForceFieldFitter(config)
            fitter.load_data(frames)
            
            assert len(fitter.energy_data) > 0
            assert len(fitter.force_data) > 0
    
    def test_ff_fitter_to_lammps_generator(self, tmp_path, mock_atoms):
        """Test integration: Force field fitter → LAMMPS generator."""
        from dft_to_lammps_bridge import (
            ForceFieldFitter, ForceFieldConfig,
            LAMMPSInputGenerator, LAMMPSInputConfig
        )
        
        working_dir = tmp_path / "ff_lammps"
        working_dir.mkdir()
        
        # Fitted parameters
        fitted_params = {
            'Li-S': {'A': 1000.0, 'rho': 0.3, 'C': 10.0}
        }
        
        # Generate LAMMPS input
        config = LAMMPSInputConfig(pair_style="buck/coul/long")
        generator = LAMMPSInputGenerator(config)
        
        with patch('dft_to_lammps_bridge.write_lammps_data'):
            input_file = generator.generate(
                atoms=mock_atoms,
                potential_params=fitted_params,
                output_file=str(working_dir / "in.lammps")
            )
        
        assert Path(input_file).exists()
        
        content = Path(input_file).read_text()
        assert "pair_style" in content
    
    def test_nep_data_to_nep_training(self, tmp_path):
        """Test integration: NEP data preparation → NEP training."""
        from nep_training_pipeline import (
            NEPDataPreparer, NEPDataConfig,
            NEPTrainer, NEPTrainingConfig, NEPModelConfig
        )
        
        working_dir = tmp_path / "nep_integration"
        working_dir.mkdir()
        
        # Prepare data
        data_config = NEPDataConfig(type_map=['Li', 'S'])
        preparer = NEPDataPreparer(data_config)
        
        # Mock frames
        preparer.frames = [
            {
                'atoms': Mock(),
                'energy': -100.0,
                'forces': np.random.randn(2, 3) * 0.1,
                'symbols': ['Li', 'S'],
                'cell': np.eye(3) * 10,
                'pbc': [True, True, True]
            }
        ]
        
        train_dir = working_dir / "data"
        train_dir.mkdir()
        
        with patch.object(preparer, '_write_xyz'):
            preparer.prepare_dataset(train_dir)
        
        # Setup training
        train_config = NEPTrainingConfig(working_dir=str(working_dir / "training"))
        trainer = NEPTrainer(train_config)
        
        assert trainer.working_dir.exists()
    
    def test_md_simulation_to_analysis(self, tmp_path):
        """Test integration: MD simulation → Analysis."""
        from code_templates.md_simulation_lammps import MDAnalyzer
        
        working_dir = tmp_path / "md_analysis"
        working_dir.mkdir()
        
        # Create mock trajectory file
        traj_file = working_dir / "dump.lammpstrj"
        traj_file.write_text("""ITEM: TIMESTEP
0
ITEM: NUMBER OF ATOMS
2
ITEM: BOX BOUNDS pp pp pp
0 10
0 10
0 10
ITEM: ATOMS id type x y z
1 1 0.0 0.0 0.0
2 2 1.0 0.0 0.0
ITEM: TIMESTEP
1
ITEM: NUMBER OF ATOMS
2
ITEM: BOX BOUNDS pp pp pp
0 10
0 10
0 10
ITEM: ATOMS id type x y z
1 1 0.1 0.0 0.0
2 2 1.1 0.0 0.0
""")
        
        analyzer = MDAnalyzer(str(traj_file))
        
        with patch('code_templates.md_simulation_lammps.read') as mock_read:
            mock_atoms1 = Mock()
            mock_atoms1.get_positions.return_value = np.array([[0, 0, 0], [1, 0, 0]])
            mock_atoms2 = Mock()
            mock_atoms2.get_positions.return_value = np.array([[0.1, 0, 0], [1.1, 0, 0]])
            mock_atoms2.get_chemical_symbols.return_value = ['Li', 'S']
            mock_atoms2.get_volume.return_value = 1000.0
            mock_atoms2.get_masses.return_value = np.array([6.94, 32.06])
            
            mock_read.return_value = [mock_atoms1, mock_atoms2]
            
            frames = analyzer.read_trajectory()
            
            assert len(frames) == 2
            
            # Test analysis
            times, msd = analyzer.compute_msd(timestep=1.0)
            
            assert len(times) == 2


# =============================================================================
# Test Class: Workflow Manager Integration
# =============================================================================

@pytest.mark.integration
class TestWorkflowManagerIntegration:
    """Test workflow manager with different schedulers."""
    
    def test_workflow_manager_with_local_scheduler(self, tmp_path):
        """Test workflow manager with local scheduler."""
        from hpc_scheduler import WorkflowManager, LocalScheduler, JobSpec, ResourceRequest
        
        working_dir = tmp_path / "workflow_manager"
        working_dir.mkdir()
        
        scheduler = LocalScheduler()
        manager = WorkflowManager(scheduler)
        
        spec = JobSpec(
            name="test_task",
            working_dir=working_dir,
            commands=["echo 'hello'"],
            resources=ResourceRequest(walltime_hours=1.0)
        )
        
        job_id = manager.submit_task("task1", spec)
        
        assert job_id is not None
        assert "local" in job_id
        assert "task1" in manager._jobs
    
    def test_workflow_with_dependencies(self, tmp_path):
        """Test workflow with task dependencies."""
        from hpc_scheduler import WorkflowManager, LocalScheduler, JobSpec, ResourceRequest
        
        working_dir = tmp_path / "workflow_deps"
        working_dir.mkdir()
        
        scheduler = LocalScheduler()
        manager = WorkflowManager(scheduler)
        
        # Task 1
        spec1 = JobSpec(
            name="task1",
            working_dir=working_dir / "task1",
            commands=["echo 'task1'"],
            resources=ResourceRequest(walltime_hours=1.0)
        )
        job1 = manager.submit_task("task1", spec1)
        
        # Task 2 depends on Task 1
        spec2 = JobSpec(
            name="task2",
            working_dir=working_dir / "task2",
            commands=["echo 'task2'"],
            resources=ResourceRequest(walltime_hours=1.0)
        )
        job2 = manager.submit_task("task2", spec2, depends_on=["task1"])
        
        assert job2 is not None
    
    def test_workflow_status_checking(self, tmp_path):
        """Test workflow status checking."""
        from hpc_scheduler import WorkflowManager, LocalScheduler, JobSpec, ResourceRequest
        
        working_dir = tmp_path / "workflow_status"
        working_dir.mkdir()
        
        scheduler = LocalScheduler()
        manager = WorkflowManager(scheduler)
        
        spec = JobSpec(
            name="status_task",
            working_dir=working_dir,
            commands=["echo 'status'"],
            resources=ResourceRequest(walltime_hours=1.0)
        )
        
        manager.submit_task("task1", spec)
        
        status = manager.get_status()
        
        assert "task1" in status
    
    def test_workflow_wait_for_all(self, tmp_path):
        """Test waiting for all tasks to complete."""
        from hpc_scheduler import WorkflowManager, LocalScheduler, JobSpec, ResourceRequest, JobStatus
        
        working_dir = tmp_path / "workflow_wait"
        working_dir.mkdir()
        
        scheduler = LocalScheduler()
        manager = WorkflowManager(scheduler)
        
        spec = JobSpec(
            name="wait_task",
            working_dir=working_dir,
            commands=["echo 'wait'"],
            resources=ResourceRequest(walltime_hours=1.0)
        )
        
        manager.submit_task("task1", spec)
        
        with patch.object(scheduler, 'wait_for_job') as mock_wait:
            mock_wait.return_value = JobStatus.COMPLETED
            
            results = manager.wait_for_all(timeout=5.0)
            
            assert "task1" in results
            assert results["task1"] == JobStatus.COMPLETED


# =============================================================================
# Test Class: Error Handling Integration
# =============================================================================

@pytest.mark.integration
class TestErrorHandlingIntegration:
    """Test error handling across module boundaries."""
    
    def test_dft_parser_error_propagation(self, tmp_path):
        """Test error propagation from DFT parser."""
        from dft_to_lammps_bridge import DFTToLAMMPSBridge
        
        working_dir = tmp_path / "dft_error"
        working_dir.mkdir()
        
        bridge = DFTToLAMMPSBridge(working_dir=str(working_dir))
        
        # Try to parse non-existent file
        with pytest.raises(FileNotFoundError):
            bridge.parse_dft_output("/nonexistent/OUTCAR")
    
    def test_ml_training_error_recovery(self, tmp_path):
        """Test error recovery in ML training."""
        from nep_training_pipeline import NEPTrainer, NEPTrainingConfig
        
        working_dir = tmp_path / "ml_error"
        working_dir.mkdir()
        
        config = NEPTrainingConfig(working_dir=str(working_dir))
        trainer = NEPTrainer(config)
        
        # Mock training failure
        with patch('subprocess.Popen') as mock_popen:
            mock_process = Mock()
            mock_process.returncode = 1
            mock_process.stdout = []
            mock_popen.return_value = mock_process
            
            with pytest.raises(Exception):
                trainer.train(verbose=False)
    
    def test_scheduler_error_handling(self, tmp_path):
        """Test scheduler error handling."""
        from hpc_scheduler import LocalScheduler, JobSpec
        
        scheduler = LocalScheduler()
        
        # Try to query non-existent job
        status = scheduler.query("nonexistent_job")
        
        assert status == []


# =============================================================================
# Test Class: Checkpoint and Recovery Integration
# =============================================================================

@pytest.mark.integration
class TestCheckpointRecovery:
    """Test checkpoint and recovery functionality."""
    
    def test_checkpoint_saving_and_loading(self, tmp_path):
        """Test checkpoint save/load functionality."""
        try:
            from checkpoint_manager import CheckpointManager
            
            checkpoint_dir = tmp_path / "checkpoints"
            checkpoint_dir.mkdir()
            
            manager = CheckpointManager(str(checkpoint_dir))
            
            # Save checkpoint
            state = {
                'stage': 'dft',
                'iteration': 5,
                'data': [1, 2, 3]
            }
            
            checkpoint_file = manager.save_checkpoint(state, "test_checkpoint")
            
            assert Path(checkpoint_file).exists()
            
            # Load checkpoint
            loaded_state = manager.load_checkpoint("test_checkpoint")
            
            assert loaded_state['stage'] == 'dft'
            assert loaded_state['iteration'] == 5
        except ImportError:
            pytest.skip("checkpoint_manager not available")
    
    def test_workflow_resumption(self, tmp_path):
        """Test workflow resumption from checkpoint."""
        try:
            from checkpoint_manager import CheckpointManager
            
            checkpoint_dir = tmp_path / "workflow_resume"
            checkpoint_dir.mkdir()
            
            manager = CheckpointManager(str(checkpoint_dir))
            
            # Simulate interrupted workflow
            state = {
                'current_stage': 2,
                'completed_stages': ['fetch_structure', 'dft_calculation'],
                'pending_stages': ['ml_training', 'md_simulation']
            }
            
            manager.save_checkpoint(state, "workflow_state")
            
            # Resume
            loaded = manager.load_checkpoint("workflow_state")
            
            assert loaded['current_stage'] == 2
            assert 'ml_training' in loaded['pending_stages']
        except ImportError:
            pytest.skip("checkpoint_manager not available")


# =============================================================================
# Standalone Integration Test Functions
# =============================================================================

@pytest.mark.integration
def test_full_materials_workflow_mock(tmp_path):
    """Test full materials workflow with all components mocked."""
    try:
        from integrated_materials_workflow import (
            IntegratedWorkflowConfig, ProgressMonitor, ErrorHandler
        )
        
        working_dir = tmp_path / "full_workflow"
        
        config = IntegratedWorkflowConfig(working_dir=str(working_dir))
        monitor = ProgressMonitor(total_stages=5)
        error_handler = ErrorHandler(config)
        
        # Verify all components are properly initialized
        assert config.working_dir == Path(working_dir)
        assert monitor.total_stages == 5
        assert error_handler.config == config
        
    except ImportError:
        pytest.skip("integrated_materials_workflow not available")


@pytest.mark.integration
def test_data_format_conversions(tmp_path):
    """Test data format conversions between modules."""
    # Test that data can flow between DFT, ML, and MD modules
    
    # DFT output format
    dft_frame = {
        'energy': -100.0,
        'forces': np.random.randn(6, 3) * 0.1,
        'positions': np.random.randn(6, 3),
        'cell': np.eye(3) * 10,
        'symbols': ['Li', 'Li', 'S', 'S', 'P', 'P']
    }
    
    # Can be used by ML training
    assert 'energy' in dft_frame
    assert 'forces' in dft_frame
    
    # Can be converted to MD input
    assert 'positions' in dft_frame
    assert 'cell' in dft_frame


@pytest.mark.integration
def test_file_path_handling(tmp_path):
    """Test that all modules handle file paths consistently."""
    from pathlib import Path
    
    test_paths = [
        tmp_path / "test.txt",
        str(tmp_path / "test.txt"),
        tmp_path / "subdir" / "test.txt",
    ]
    
    for path in test_paths:
        if isinstance(path, str):
            path_obj = Path(path)
        else:
            path_obj = path
        
        # All should be valid Path objects
        assert isinstance(path_obj, Path)