"""
DFT Workflow Unit Tests
=======================

Tests for the DFT-related functionality in dft_to_lammps_bridge.py:
- VASP OUTCAR parsing
- Force field fitting
- LAMMPS input generation
- QM/MM boundary handling

Run with: pytest tests/test_dft_workflow.py -v
"""

import os
import sys
import json
import pytest
import numpy as np
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock, mock_open, call
from io import StringIO

# Import fixtures from conftest.py automatically


# =============================================================================
# Test Class: VASP Parser Tests
# =============================================================================

@pytest.mark.unit
@pytest.mark.dft
class TestVASPOUTCARParser:
    """Test suite for VASP OUTCAR parser."""
    
    def test_parser_initialization(self, mock_vasp_config):
        """Test parser initialization with configuration."""
        from dft_to_lammps_bridge import VASPOUTCARParser, VASPParserConfig
        
        parser = VASPOUTCARParser(mock_vasp_config)
        
        assert parser.config == mock_vasp_config
        assert parser.frames == []
    
    def test_parser_default_config(self):
        """Test parser initialization with default configuration."""
        from dft_to_lammps_bridge import VASPOUTCARParser, VASPParserConfig
        
        parser = VASPOUTCARParser()
        
        assert parser.config is not None
        assert isinstance(parser.config, VASPParserConfig)
        assert parser.config.extract_energy is True
    
    def test_parse_nonexistent_file(self, mock_vasp_parser, mock_working_dir):
        """Test parsing a non-existent file raises FileNotFoundError."""
        nonexistent_file = mock_working_dir / "nonexistent_OUTCAR"
        
        with pytest.raises(FileNotFoundError):
            mock_vasp_parser.parse(nonexistent_file)
    
    def test_parse_mock_outcar(self, mock_vasp_parser, mock_working_dir, mock_outcar_content):
        """Test parsing a mock OUTCAR file."""
        outcar_path = mock_working_dir / "OUTCAR"
        outcar_path.write_text(mock_outcar_content)
        
        frames = mock_vasp_parser.parse(outcar_path)
        
        assert len(frames) > 0
        assert 'energy' in frames[0] or frames[0]['energy'] is None
    
    def test_extract_frame_data(self, mock_vasp_parser, mock_atoms):
        """Test extracting frame data from ASE Atoms."""
        frame = mock_vasp_parser._extract_frame_data(mock_atoms, index=0)
        
        assert frame is not None
        assert frame['index'] == 0
        assert 'symbols' in frame
        assert 'positions' in frame
        assert 'cell' in frame
    
    def test_extract_energy(self, mock_vasp_parser, mock_atoms):
        """Test energy extraction from atoms."""
        mock_vasp_parser.config.extract_energy = True
        frame = mock_vasp_parser._extract_frame_data(mock_atoms, index=0)
        
        if 'energy' in frame:
            assert isinstance(frame['energy'], (float, type(None)))
    
    def test_extract_forces(self, mock_vasp_parser, mock_atoms):
        """Test forces extraction configuration."""
        mock_vasp_parser.config.extract_forces = True
        frame = mock_vasp_parser._extract_frame_data(mock_atoms, index=0)
        
        if 'forces' in frame:
            assert isinstance(frame['forces'], (np.ndarray, type(None)))
    
    def test_filter_frames(self, mock_vasp_parser, mock_dft_frames):
        """Test filtering frames with outlier detection."""
        mock_vasp_parser.frames = mock_dft_frames
        filtered = mock_vasp_parser._filter_frames(mock_dft_frames)
        
        assert len(filtered) <= len(mock_dft_frames)
        assert all(isinstance(f, dict) for f in filtered)
    
    def test_get_statistics(self, mock_vasp_parser, mock_dft_frames):
        """Test getting statistics from parsed frames."""
        mock_vasp_parser.frames = mock_dft_frames
        stats = mock_vasp_parser.get_statistics()
        
        assert 'n_frames' in stats
        assert stats['n_frames'] == len(mock_dft_frames)
        if 'energy' in stats:
            assert 'mean' in stats['energy']
            assert 'std' in stats['energy']
    
    def test_to_xyz(self, mock_vasp_parser, mock_dft_frames, mock_working_dir):
        """Test exporting frames to XYZ format."""
        try:
            from ase import Atoms
            mock_vasp_parser.frames = mock_dft_frames
            
            # Add mock atoms to frames
            for frame in mock_vasp_parser.frames:
                frame['atoms'] = Atoms(
                    symbols=frame['symbols'],
                    positions=frame['positions'],
                    cell=frame['cell'],
                    pbc=frame['pbc']
                )
            
            output_file = mock_working_dir / "output.xyz"
            mock_vasp_parser.to_xyz(str(output_file))
            
            assert output_file.exists()
        except ImportError:
            pytest.skip("ASE not available")
    
    def test_parse_multiple(self, mock_vasp_parser, mock_working_dir, mock_outcar_content):
        """Test parsing multiple OUTCAR files."""
        outcar1 = mock_working_dir / "OUTCAR.1"
        outcar2 = mock_working_dir / "OUTCAR.2"
        outcar1.write_text(mock_outcar_content)
        outcar2.write_text(mock_outcar_content)
        
        with patch.object(mock_vasp_parser, 'parse') as mock_parse:
            mock_parse.return_value = [{'energy': -100.0}]
            frames = mock_vasp_parser.parse_multiple([outcar1, outcar2])
            
            assert mock_parse.call_count == 2
    
    def test_manual_parse_fallback(self, mock_vasp_parser, mock_working_dir):
        """Test manual parsing fallback when ASE fails."""
        outcar_path = mock_working_dir / "OUTCAR"
        outcar_path.write_text("""
FREE ENERGIE OF THE ION-ELECTRON SYSTEM
free  energy   TOTEN  =      -100.12345678 eV
""")
        
        with patch('dft_to_lammps_bridge.read_vasp_out') as mock_read:
            mock_read.side_effect = Exception("ASE parse error")
            
            with patch.object(mock_vasp_parser, '_manual_parse', return_value=[{'energy': -100.0}]):
                frames = mock_vasp_parser.parse(outcar_path)


# =============================================================================
# Test Class: Force Field Fitter Tests
# =============================================================================

@pytest.mark.unit
class TestForceFieldFitter:
    """Test suite for force field fitting."""
    
    def test_fitter_initialization(self, mock_ff_config):
        """Test fitter initialization with configuration."""
        from dft_to_lammps_bridge import ForceFieldFitter
        
        fitter = ForceFieldFitter(mock_ff_config)
        
        assert fitter.config == mock_ff_config
        assert fitter.energy_data == []
        assert fitter.force_data == []
        assert fitter.structures == []
        assert fitter.fitted_params is None
    
    def test_load_data(self, mock_ff_fitter, mock_dft_frames):
        """Test loading training data."""
        mock_ff_fitter.load_data(mock_dft_frames)
        
        assert len(mock_ff_fitter.energy_data) == len(mock_dft_frames)
        assert len(mock_ff_fitter.force_data) == len(mock_dft_frames)
        assert len(mock_ff_fitter.structures) == len(mock_dft_frames)
    
    def test_get_elements(self, mock_ff_fitter, mock_atoms):
        """Test automatic element detection."""
        mock_ff_fitter.structures = [mock_atoms]
        elements = mock_ff_fitter._get_elements()
        
        assert isinstance(elements, list)
        assert len(elements) > 0
        assert 'Li' in elements or 'S' in elements or 'P' in elements
    
    def test_fit_buckingham(self, mock_ff_fitter, mock_dft_frames):
        """Test Buckingham potential fitting."""
        mock_ff_fitter.config.ff_type = "buckingham"
        mock_ff_fitter.config.elements = ['Li', 'S']
        mock_ff_fitter.load_data(mock_dft_frames)
        
        # Mock the least_squares to avoid actual optimization
        with patch('dft_to_lammps_bridge.least_squares') as mock_ls:
            mock_ls.return_value = Mock(x=[1000.0, 0.3, 10.0])
            
            params = mock_ff_fitter._fit_buckingham()
            
            assert isinstance(params, dict)
            assert 'Li-S' in params or 'S-Li' in params
    
    def test_fit_morse(self, mock_ff_fitter, mock_dft_frames):
        """Test Morse potential fitting."""
        mock_ff_fitter.config.ff_type = "morse"
        mock_ff_fitter.config.elements = ['Li', 'S']
        mock_ff_fitter.load_data(mock_dft_frames)
        
        with patch('dft_to_lammps_bridge.least_squares') as mock_ls:
            mock_ls.return_value = Mock(x=[1.0, 1.5, 2.0])
            
            params = mock_ff_fitter._fit_morse()
            
            assert isinstance(params, dict)
    
    def test_fit_lennard_jones(self, mock_ff_fitter, mock_dft_frames):
        """Test Lennard-Jones potential fitting."""
        mock_ff_fitter.config.ff_type = "lj"
        mock_ff_fitter.config.elements = ['Li', 'S']
        mock_ff_fitter.load_data(mock_dft_frames)
        
        with patch('dft_to_lammps_bridge.least_squares') as mock_ls:
            mock_ls.return_value = Mock(x=[0.1, 3.0])
            
            params = mock_ff_fitter._fit_lennard_jones()
            
            assert isinstance(params, dict)
    
    def test_buckingham_residuals(self, mock_ff_fitter, mock_atoms):
        """Test Buckingham residuals calculation."""
        mock_ff_fitter.structures = [mock_atoms]
        mock_ff_fitter.energy_data = [-100.0]
        mock_ff_fitter.config.cutoff = 6.0
        
        params = np.array([1000.0, 0.3, 10.0])
        residuals = mock_ff_fitter._buckingham_residuals(params, ('Li', 'S'))
        
        assert isinstance(residuals, np.ndarray)
        assert len(residuals) > 0
    
    def test_calc_buckingham_energy(self, mock_ff_fitter, mock_atoms):
        """Test Buckingham energy calculation."""
        energy = mock_ff_fitter._calc_buckingham_energy(
            mock_atoms, ('Li', 'S'), A=1000.0, rho=0.3, C=10.0
        )
        
        assert isinstance(energy, (float, np.floating))
    
    def test_save_and_load_params(self, mock_ff_fitter, mock_working_dir):
        """Test saving and loading fitted parameters."""
        params = {'Li-S': {'A': 1000.0, 'rho': 0.3, 'C': 10.0}}
        mock_ff_fitter.fitted_params = params
        
        param_file = mock_working_dir / "params.json"
        mock_ff_fitter.save_params(str(param_file))
        
        assert param_file.exists()
        
        # Clear and reload
        mock_ff_fitter.fitted_params = None
        mock_ff_fitter.load_params(str(param_file))
        
        assert mock_ff_fitter.fitted_params == params
    
    def test_validate(self, mock_ff_fitter, mock_dft_frames):
        """Test validation of fitted force field."""
        mock_ff_fitter.fitted_params = {'Li-S': {'A': 1000.0}}
        
        validation = mock_ff_fitter.validate(mock_dft_frames)
        
        assert isinstance(validation, dict)
    
    def test_validate_without_fitting_raises_error(self, mock_ff_fitter, mock_dft_frames):
        """Test that validation raises error when no parameters are fitted."""
        mock_ff_fitter.fitted_params = None
        
        with pytest.raises(ValueError, match="Must fit force field before validation"):
            mock_ff_fitter.validate(mock_dft_frames)


# =============================================================================
# Test Class: LAMMPS Input Generator Tests
# =============================================================================

@pytest.mark.unit
@pytest.mark.md
class TestLAMMPSInputGenerator:
    """Test suite for LAMMPS input file generation."""
    
    def test_generator_initialization(self, mock_lammps_config):
        """Test generator initialization."""
        from dft_to_lammps_bridge import LAMMPSInputGenerator
        
        generator = LAMMPSInputGenerator(mock_lammps_config)
        
        assert generator.config == mock_lammps_config
        assert generator.input_lines == []
    
    def test_generate_input(self, mock_lammps_generator, mock_atoms, mock_working_dir):
        """Test generating LAMMPS input file."""
        mock_lammps_generator.config.working_dir = str(mock_working_dir)
        
        with patch('dft_to_lammps_bridge.write_lammps_data'):
            input_file = mock_lammps_generator.generate(
                atoms=mock_atoms,
                potential_params={'Li-S': {'A': 1000.0, 'rho': 0.3, 'C': 10.0}},
                output_file=str(mock_working_dir / "in.lammps")
            )
        
        assert Path(input_file).exists()
    
    def test_add_header(self, mock_lammps_generator):
        """Test header generation."""
        mock_lammps_generator._add_header()
        
        assert len(mock_lammps_generator.input_lines) > 0
        assert "LAMMPS input file" in mock_lammps_generator.input_lines[0]
    
    def test_add_initialization(self, mock_lammps_generator):
        """Test initialization section generation."""
        mock_lammps_generator._add_initialization()
        
        assert any("units metal" in line for line in mock_lammps_generator.input_lines)
        assert any("atom_style" in line for line in mock_lammps_generator.input_lines)
    
    def test_setup_buckingham(self, mock_lammps_generator):
        """Test Buckingham potential setup."""
        mock_lammps_generator.config.pair_style = "buck/coul/long"
        mock_lammps_generator.atoms = Mock()
        mock_lammps_generator.atoms.get_chemical_symbols.return_value = ['Li', 'S']
        mock_lammps_generator.potential_params = {'Li-S': {'A': 1000.0, 'rho': 0.3, 'C': 10.0}}
        
        mock_lammps_generator._setup_buckingham()
        
        assert any("pair_style" in line for line in mock_lammps_generator.input_lines)
        assert any("pair_coeff" in line for line in mock_lammps_generator.input_lines)
    
    def test_setup_lj(self, mock_lammps_generator):
        """Test Lennard-Jones potential setup."""
        mock_lammps_generator.config.pair_style = "lj/cut"
        mock_lammps_generator.atoms = Mock()
        mock_lammps_generator.atoms.get_chemical_symbols.return_value = ['Li', 'S']
        mock_lammps_generator.potential_params = {'Li-S': {'epsilon': 0.1, 'sigma': 3.0}}
        
        mock_lammps_generator._setup_lj()
        
        assert any("pair_style lj/cut" in line for line in mock_lammps_generator.input_lines)
    
    def test_setup_morse(self, mock_lammps_generator):
        """Test Morse potential setup."""
        mock_lammps_generator.config.pair_style = "morse"
        mock_lammps_generator.atoms = Mock()
        mock_lammps_generator.atoms.get_chemical_symbols.return_value = ['Li', 'S']
        mock_lammps_generator.potential_params = {'Li-S': {'D_e': 1.0, 'a': 1.5, 'r_e': 2.0}}
        
        mock_lammps_generator._setup_morse()
        
        assert any("pair_style morse" in line for line in mock_lammps_generator.input_lines)
    
    def test_add_run_commands_nve(self, mock_lammps_generator):
        """Test NVE ensemble run commands."""
        mock_lammps_generator.config.ensemble = "nve"
        mock_lammps_generator.config.nsteps = 1000
        
        mock_lammps_generator._add_run_commands()
        
        assert any("fix ensemble all nve" in line for line in mock_lammps_generator.input_lines)
    
    def test_add_run_commands_nvt(self, mock_lammps_generator):
        """Test NVT ensemble run commands."""
        mock_lammps_generator.config.ensemble = "nvt"
        mock_lammps_generator.config.temperature = 300.0
        mock_lammps_generator.config.nsteps = 1000
        
        mock_lammps_generator._add_run_commands()
        
        assert any("fix ensemble all nvt" in line for line in mock_lammps_generator.input_lines)
    
    def test_add_run_commands_npt(self, mock_lammps_generator):
        """Test NPT ensemble run commands."""
        mock_lammps_generator.config.ensemble = "npt"
        mock_lammps_generator.config.temperature = 300.0
        mock_lammps_generator.config.pressure = 1.0
        mock_lammps_generator.config.nsteps = 1000
        
        mock_lammps_generator._add_run_commands()
        
        assert any("fix ensemble all npt" in line for line in mock_lammps_generator.input_lines)
    
    def test_add_run_commands_npt_without_pressure_raises(self, mock_lammps_generator):
        """Test that NPT without pressure raises error."""
        mock_lammps_generator.config.ensemble = "npt"
        mock_lammps_generator.config.pressure = None
        
        with pytest.raises(ValueError, match="Pressure must be specified"):
            mock_lammps_generator._add_run_commands()


# =============================================================================
# Test Class: QM/MM Boundary Handler Tests
# =============================================================================

@pytest.mark.unit
class TestQMMMBoundaryHandler:
    """Test suite for QM/MM boundary handling."""
    
    def test_handler_initialization(self):
        """Test QM/MM handler initialization."""
        from dft_to_lammps_bridge import QMMMBoundaryHandler, QM-MMConfig
        
        config = QM-MMConfig(qm_region=[0, 1, 2], coupling_scheme="mechanical")
        handler = QMMMBoundaryHandler(config)
        
        assert handler.config == config
        assert handler.qm_atoms is None
        assert handler.mm_atoms is None
    
    def test_auto_detect_qm_region(self, mock_atoms):
        """Test automatic QM region detection."""
        from dft_to_lammps_bridge import QMMMBoundaryHandler, QM-MMConfig
        
        config = QM-MMConfig()
        handler = QMMMBoundaryHandler(config)
        
        qm_region = handler._auto_detect_qm_region(mock_atoms)
        
        assert isinstance(qm_region, list)
        assert len(qm_region) > 0
        assert all(isinstance(i, int) for i in qm_region)
    
    def test_calculate_link_position(self):
        """Test link atom position calculation."""
        from dft_to_lammps_bridge import QMMMBoundaryHandler, QM-MMConfig
        
        handler = QMMMBoundaryHandler(QM-MMConfig())
        qm_pos = np.array([0.0, 0.0, 0.0])
        mm_pos = np.array([1.0, 0.0, 0.0])
        
        link_pos = handler._calculate_link_position(qm_pos, mm_pos)
        
        assert isinstance(link_pos, np.ndarray)
        assert len(link_pos) == 3
    
    def test_get_mm_charges(self, mock_atoms):
        """Test getting MM atom charges."""
        from dft_to_lammps_bridge import QMMMBoundaryHandler, QM-MMConfig
        
        config = QM-MMConfig(charge_dict={'Li': 1.0, 'S': -2.0, 'P': 0.0})
        handler = QMMMBoundaryHandler(config)
        
        charges = handler._get_mm_charges(mock_atoms)
        
        assert isinstance(charges, np.ndarray)
        assert len(charges) == len(mock_atoms)


# =============================================================================
# Test Class: DFTToLAMMPSBridge Integration
# =============================================================================

@pytest.mark.integration
@pytest.mark.dft
class TestDFTToLAMMPSBridge:
    """Test suite for the main DFT to LAMMPS bridge workflow."""
    
    def test_bridge_initialization(self, mock_working_dir):
        """Test bridge workflow initialization."""
        from dft_to_lammps_bridge import DFTToLAMMPSBridge
        
        bridge = DFTToLAMMPSBridge(working_dir=str(mock_working_dir))
        
        assert bridge.working_dir == mock_working_dir
        assert bridge.parser is None
        assert bridge.fitter is None
        assert bridge.frames == []
    
    def test_parse_dft_output(self, mock_working_dir, mock_outcar_content):
        """Test parsing DFT output in bridge workflow."""
        from dft_to_lammps_bridge import DFTToLAMMPSBridge
        
        bridge = DFTToLAMMPSBridge(working_dir=str(mock_working_dir))
        
        outcar_path = mock_working_dir / "OUTCAR"
        outcar_path.write_text(mock_outcar_content)
        
        with patch.object(bridge, '_save_statistics'):
            frames = bridge.parse_dft_output(outcar_path, code="vasp")
        
        assert bridge.parser is not None
        assert bridge.frames is not None
    
    def test_fit_force_field_requires_frames(self, mock_working_dir):
        """Test that fitting requires parsed frames."""
        from dft_to_lammps_bridge import DFTToLAMMPSBridge
        
        bridge = DFTToLAMMPSBridge(working_dir=str(mock_working_dir))
        
        with pytest.raises(ValueError, match="No DFT data available"):
            bridge.fit_force_field(ff_type="buckingham")
    
    def test_generate_lammps_input(self, mock_working_dir, mock_atoms):
        """Test generating LAMMPS input in bridge workflow."""
        from dft_to_lammps_bridge import DFTToLAMMPSBridge
        
        bridge = DFTToLAMMPSBridge(working_dir=str(mock_working_dir))
        
        with patch('dft_to_lammps_bridge.write_lammps_data'):
            with patch.object(bridge.lammps_generator, 'generate'):
                input_file = bridge.generate_lammps_input(atoms=mock_atoms)


# =============================================================================
# Test Class: Quantum ESPRESSO Parser
# =============================================================================

@pytest.mark.unit
@pytest.mark.dft
class TestQuantumESPRESSOParser:
    """Test suite for Quantum ESPRESSO parser."""
    
    def test_parser_initialization(self):
        """Test QE parser initialization."""
        from dft_to_lammps_bridge import QuantumESPRESSOParser
        
        parser = QuantumESPRESSOParser()
        
        assert parser.frames == []
    
    def test_parse_nonexistent_file(self, mock_working_dir):
        """Test parsing non-existent QE output file."""
        from dft_to_lammps_bridge import QuantumESPRESSOParser
        
        parser = QuantumESPRESSOParser()
        nonexistent_file = mock_working_dir / "nonexistent.pwo"
        
        with pytest.raises(FileNotFoundError):
            parser.parse(nonexistent_file)


# =============================================================================
# Standalone Test Functions
# =============================================================================

@pytest.mark.unit
def test_dataclass_vasp_parser_config():
    """Test VASPParserConfig dataclass."""
    from dft_to_lammps_bridge import VASPParserConfig
    
    config = VASPParserConfig(
        extract_energy=True,
        extract_forces=False,
        energy_threshold=50.0
    )
    
    assert config.extract_energy is True
    assert config.extract_forces is False
    assert config.energy_threshold == 50.0


@pytest.mark.unit
def test_dataclass_force_field_config():
    """Test ForceFieldConfig dataclass."""
    from dft_to_lammps_bridge import ForceFieldConfig
    
    config = ForceFieldConfig(
        ff_type="morse",
        elements=['Li', 'S'],
        cutoff=5.0
    )
    
    assert config.ff_type == "morse"
    assert config.elements == ['Li', 'S']
    assert config.cutoff == 5.0


@pytest.mark.unit
def test_dataclass_lammps_input_config():
    """Test LAMMPSInputConfig dataclass."""
    from dft_to_lammps_bridge import LAMMPSInputConfig
    
    config = LAMMPSInputConfig(
        units="real",
        ensemble="npt",
        temperature=500.0,
        pressure=10.0
    )
    
    assert config.units == "real"
    assert config.ensemble == "npt"
    assert config.temperature == 500.0
    assert config.pressure == 10.0