"""
Performance and Benchmark Tests
===============================

Tests for measuring code performance:
- DFT parsing speed
- Force field fitting performance
- MD simulation throughput
- Memory usage benchmarks

Run with: pytest tests/test_performance.py -v --benchmark-only
"""

import os
import sys
import time
import json
import pytest
import numpy as np
from pathlib import Path
from unittest.mock import Mock, patch
import tempfile


# =============================================================================
# Benchmark Fixtures
# =============================================================================

@pytest.fixture
def large_trajectory():
    """Generate a large trajectory for benchmarking."""
    try:
        from ase import Atoms
        frames = []
        for i in range(1000):
            atoms = Atoms(
                symbols=['Li', 'S', 'P'] * 20,  # 60 atoms
                positions=np.random.randn(60, 3) * 10,
                cell=[20, 20, 20],
                pbc=True
            )
            atoms.info['energy'] = -500.0 + i * 0.1
            frames.append(atoms)
        return frames
    except ImportError:
        pytest.skip("ASE not available")


@pytest.fixture
def large_dft_frames():
    """Generate a large number of DFT frames for benchmarking."""
    frames = []
    for i in range(500):
        frame = {
            'index': i,
            'energy': -100.0 + i * 0.01,
            'forces': np.random.randn(20, 3) * 0.1,
            'stress': np.random.randn(6) * 0.01,
            'positions': np.random.randn(20, 3) * 5,
            'cell': np.eye(3) * 10,
            'symbols': ['Li', 'S', 'P', 'Li', 'S'] * 4
        }
        frames.append(frame)
    return frames


# =============================================================================
# Performance Test Class: DFT Workflow
# =============================================================================

@pytest.mark.benchmark
@pytest.mark.slow
class TestDFTWorkflowPerformance:
    """Performance tests for DFT workflow components."""
    
    @pytest.mark.timeout(30)
    def test_vasp_parser_performance(self, tmp_path):
        """Benchmark VASP OUTCAR parsing speed."""
        from dft_to_lammps_bridge import VASPOUTCARParser
        
        # Create large mock OUTCAR
        outcar = tmp_path / "OUTCAR"
        content = "FREE ENERGIE OF THE ION-ELECTRON SYSTEM\n"
        for i in range(100):
            content += f"free  energy   TOTEN  =      {-100.0 + i*0.1:.8f} eV\n"
        outcar.write_text(content)
        
        parser = VASPOUTCARParser()
        
        with patch('dft_to_lammps_bridge.read_vasp_out') as mock_read:
            mock_frames = []
            for i in range(100):
                mock_atoms = Mock()
                mock_atoms.calc = Mock()
                mock_atoms.calc.get_potential_energy.return_value = -100.0 + i*0.1
                mock_atoms.calc.get_forces.return_value = np.random.randn(10, 3) * 0.1
                mock_frames.append(mock_atoms)
            mock_read.return_value = mock_frames
            
            start_time = time.time()
            frames = parser.parse(outcar)
            elapsed = time.time() - start_time
            
            # Should parse 100 frames in less than 5 seconds
            assert elapsed < 5.0
            assert len(frames) == 100
    
    @pytest.mark.timeout(30)
    def test_force_field_fitting_performance(self, large_dft_frames):
        """Benchmark force field fitting performance."""
        from dft_to_lammps_bridge import ForceFieldFitter, ForceFieldConfig
        
        config = ForceFieldConfig(
            ff_type="buckingham",
            elements=['Li', 'S', 'P'],
            max_iterations=10
        )
        fitter = ForceFieldFitter(config)
        fitter.load_data(large_dft_frames)
        
        with patch('dft_to_lammps_bridge.least_squares') as mock_ls:
            mock_ls.return_value = Mock(x=[1000.0, 0.3, 10.0])
            
            start_time = time.time()
            params = fitter.fit()
            elapsed = time.time() - start_time
            
            # Fitting should complete in less than 2 seconds (with mocks)
            assert elapsed < 2.0
    
    @pytest.mark.timeout(30)
    def test_lammps_input_generation_performance(self, large_trajectory):
        """Benchmark LAMMPS input generation."""
        from dft_to_lammps_bridge import LAMMPSInputGenerator, LAMMPSInputConfig
        
        config = LAMMPSInputConfig()
        generator = LAMMPSInputGenerator(config)
        
        atoms = large_trajectory[0]
        
        with patch('dft_to_lammps_bridge.write_lammps_data'):
            start_time = time.time()
            for _ in range(100):
                input_file = generator.generate(
                    atoms=atoms,
                    potential_params={'Li-S': {'A': 1000.0}},
                    output_file="/tmp/test.in"
                )
            elapsed = time.time() - start_time
            
            # 100 generations should take less than 1 second
            assert elapsed < 1.0


# =============================================================================
# Performance Test Class: ML Training
# =============================================================================

@pytest.mark.benchmark
@pytest.mark.slow
class TestMLTrainingPerformance:
    """Performance tests for ML training components."""
    
    @pytest.mark.timeout(30)
    def test_nep_data_preparation_performance(self, tmp_path, large_trajectory):
        """Benchmark NEP data preparation."""
        from nep_training_pipeline import NEPDataPreparer, NEPDataConfig
        
        config = NEPDataConfig(type_map=['Li', 'S', 'P'])
        preparer = NEPDataPreparer(config)
        
        output_dir = tmp_path / "nep_data"
        output_dir.mkdir()
        
        start_time = time.time()
        
        # Simulate loading and preparing data
        for atoms in large_trajectory[:100]:  # Use subset for speed
            frame = preparer._extract_frame_data(atoms)
            if frame:
                preparer.frames.append(frame)
        
        elapsed = time.time() - start_time
        
        # Should process 100 frames in less than 5 seconds
        assert elapsed < 5.0
        assert len(preparer.frames) == 100
    
    @pytest.mark.timeout(30)
    def test_nep_input_generation_performance(self, tmp_path):
        """Benchmark NEP input file generation."""
        from nep_training_pipeline import NEPInputGenerator, NEPModelConfig
        
        config = NEPModelConfig(
            type_list=['Li', 'S', 'P', 'O', 'Na', 'Cl', 'K', 'Br'],
            version=4,
            n_max_radial=6,
            n_max_angular=6
        )
        generator = NEPInputGenerator(config)
        
        output_file = tmp_path / "nep.in"
        
        start_time = time.time()
        for _ in range(1000):
            generator.generate(str(output_file))
        elapsed = time.time() - start_time
        
        # 1000 generations should take less than 1 second
        assert elapsed < 1.0
    
    @pytest.mark.timeout(30)
    def test_nep_xyz_write_performance(self, tmp_path, large_trajectory):
        """Benchmark NEP XYZ file writing."""
        from nep_training_pipeline import NEPDataPreparer, NEPDataConfig
        
        config = NEPDataConfig()
        preparer = NEPDataPreparer(config)
        
        # Prepare frames
        frames = []
        for atoms in large_trajectory[:100]:
            frame = {
                'atoms': atoms,
                'energy': atoms.info.get('energy', 0.0),
                'forces': np.random.randn(len(atoms), 3) * 0.1
            }
            frames.append(frame)
        
        output_file = tmp_path / "test.xyz"
        
        start_time = time.time()
        preparer._write_xyz(output_file, frames)
        elapsed = time.time() - start_time
        
        # Should write 100 frames in less than 2 seconds
        assert elapsed < 2.0
        assert output_file.exists()


# =============================================================================
# Performance Test Class: MD Simulation
# =============================================================================

@pytest.mark.benchmark
@pytest.mark.slow
class TestMDSimulationPerformance:
    """Performance tests for MD simulation components."""
    
    @pytest.mark.timeout(30)
    def test_md_trajectory_reading_performance(self, tmp_path):
        """Benchmark MD trajectory reading."""
        from code_templates.md_simulation_lammps import MDAnalyzer
        
        # Create mock trajectory file
        traj_file = tmp_path / "dump.lammpstrj"
        content = ""
        for i in range(1000):
            content += f"""ITEM: TIMESTEP
{i}
ITEM: NUMBER OF ATOMS
60
ITEM: BOX BOUNDS pp pp pp
0 20
0 20
0 20
ITEM: ATOMS id type x y z
"""
            for j in range(60):
                content += f"{j+1} {j%3+1} {np.random.rand():.6f} {np.random.rand():.6f} {np.random.rand():.6f}\n"
        
        traj_file.write_text(content)
        
        analyzer = MDAnalyzer(str(traj_file))
        
        with patch('code_templates.md_simulation_lammps.read') as mock_read:
            mock_frames = []
            for _ in range(1000):
                mock_atoms = Mock()
                mock_atoms.get_positions.return_value = np.random.randn(60, 3)
                mock_frames.append(mock_atoms)
            mock_read.return_value = mock_frames
            
            start_time = time.time()
            frames = analyzer.read_trajectory()
            elapsed = time.time() - start_time
            
            # Should read 1000 frames in less than 5 seconds
            assert elapsed < 5.0
            assert len(frames) == 1000
    
    @pytest.mark.timeout(30)
    def test_msd_calculation_performance(self):
        """Benchmark MSD calculation."""
        from code_templates.md_simulation_lammps import MDAnalyzer
        
        # Create mock trajectory
        mock_frames = []
        np.random.seed(42)
        positions = np.cumsum(np.random.randn(1000, 3) * 0.01, axis=0)
        
        for pos in positions:
            mock_atoms = Mock()
            mock_atoms.get_positions.return_value = np.array([pos, pos + [1, 0, 0]])
            mock_frames.append(mock_atoms)
        
        analyzer = MDAnalyzer("test.dump")
        analyzer.trajectory = mock_frames
        
        start_time = time.time()
        times, msd = analyzer.compute_msd(timestep=1.0)
        elapsed = time.time() - start_time
        
        # MSD calculation for 1000 frames should take less than 1 second
        assert elapsed < 1.0
        assert len(msd) == 1000
    
    @pytest.mark.timeout(30)
    def test_diffusion_coefficient_performance(self):
        """Benchmark diffusion coefficient calculation."""
        from code_templates.md_simulation_lammps import MDAnalyzer
        
        # Create mock trajectory with known diffusion
        mock_frames = []
        np.random.seed(42)
        for i in range(500):
            mock_atoms = Mock()
            positions = np.cumsum(np.random.randn(2, 3) * 0.01, axis=0)
            mock_atoms.get_positions.return_value = positions
            mock_atoms.get_chemical_symbols.return_value = ['Li', 'S']
            mock_frames.append(mock_atoms)
        
        analyzer = MDAnalyzer("test.dump")
        analyzer.trajectory = mock_frames
        
        start_time = time.time()
        D = analyzer.compute_diffusion_coefficient(
            atom_type='Li',
            start_frame=10,
            end_frame=500,
            timestep=1.0
        )
        elapsed = time.time() - start_time
        
        # Should compute in less than 1 second
        assert elapsed < 1.0
        assert isinstance(D, float)


# =============================================================================
# Performance Test Class: HPC Scheduler
# =============================================================================

@pytest.mark.benchmark
@pytest.mark.slow
class TestHPCSchedulerPerformance:
    """Performance tests for HPC scheduler operations."""
    
    @pytest.mark.timeout(30)
    def test_scheduler_script_generation_performance(self, mock_job_spec):
        """Benchmark scheduler script generation."""
        from hpc_scheduler import SlurmScheduler, PBSScheduler, LSFScheduler
        
        schedulers = [
            SlurmScheduler(),
            PBSScheduler(),
            LSFScheduler()
        ]
        
        for scheduler in schedulers:
            start_time = time.time()
            for _ in range(1000):
                script = scheduler.generate_script(mock_job_spec)
            elapsed = time.time() - start_time
            
            # 1000 script generations should take less than 2 seconds
            assert elapsed < 2.0, f"{scheduler.__class__.__name__} too slow"
    
    @pytest.mark.timeout(30)
    def test_job_query_performance(self):
        """Benchmark job query performance."""
        from hpc_scheduler import LocalScheduler, JobSpec, ResourceRequest
        
        scheduler = LocalScheduler()
        
        # Submit multiple jobs
        job_ids = []
        for i in range(100):
            spec = JobSpec(
                name=f"job_{i}",
                working_dir=Path("/tmp"),
                commands=["echo 'test'"],
                resources=ResourceRequest()
            )
            with patch('subprocess.Popen') as mock_popen:
                mock_process = Mock()
                mock_process.poll.return_value = 0  # Completed
                mock_popen.return_value = mock_process
                job_id = scheduler.submit(spec)
                job_ids.append(job_id)
        
        start_time = time.time()
        jobs = scheduler.query()
        elapsed = time.time() - start_time
        
        # Querying 100 jobs should take less than 1 second
        assert elapsed < 1.0
        assert len(jobs) == 100


# =============================================================================
# Memory Benchmark Tests
# =============================================================================

@pytest.mark.benchmark
@pytest.mark.slow
class TestMemoryBenchmarks:
    """Memory usage benchmarks."""
    
    @pytest.mark.timeout(60)
    def test_large_trajectory_memory_usage(self, tmp_path):
        """Test memory efficiency with large trajectories."""
        import psutil
        import os
        
        process = psutil.Process(os.getpid())
        initial_memory = process.memory_info().rss / 1024 / 1024  # MB
        
        # Create large trajectory
        try:
            from ase import Atoms
            frames = []
            for i in range(100):  # 100 frames, 600 atoms each
                atoms = Atoms(
                    symbols=['Li', 'S', 'P'] * 200,
                    positions=np.random.randn(600, 3) * 20,
                    cell=[40, 40, 40],
                    pbc=True
                )
                frames.append(atoms)
            
            current_memory = process.memory_info().rss / 1024 / 1024  # MB
            memory_increase = current_memory - initial_memory
            
            # Should use less than 500 MB for 100 frames of 600 atoms
            assert memory_increase < 500, f"Memory usage too high: {memory_increase} MB"
        except ImportError:
            pytest.skip("ASE not available")
    
    @pytest.mark.timeout(30)
    def test_nep_data_memory_efficiency(self, large_trajectory):
        """Test NEP data preparation memory efficiency."""
        import psutil
        import os
        
        process = psutil.Process(os.getpid())
        
        from nep_training_pipeline import NEPDataPreparer, NEPDataConfig
        
        config = NEPDataConfig()
        preparer = NEPDataPreparer(config)
        
        start_memory = process.memory_info().rss / 1024 / 1024  # MB
        
        # Process frames
        for atoms in large_trajectory[:50]:
            frame = preparer._extract_frame_data(atoms)
            if frame:
                preparer.frames.append(frame)
        
        end_memory = process.memory_info().rss / 1024 / 1024  # MB
        memory_per_frame = (end_memory - start_memory) / len(preparer.frames)
        
        # Should use less than 5 MB per frame on average
        assert memory_per_frame < 5, f"Memory per frame too high: {memory_per_frame} MB"


# =============================================================================
# Scalability Tests
# =============================================================================

@pytest.mark.benchmark
@pytest.mark.slow
class TestScalability:
    """Tests for code scalability."""
    
    @pytest.mark.timeout(60)
    def test_parser_scalability(self, tmp_path):
        """Test parser scalability with increasing frame count."""
        from dft_to_lammps_bridge import VASPOUTCARParser
        
        parser = VASPOUTCARParser()
        
        frame_counts = [10, 50, 100]
        times = []
        
        for count in frame_counts:
            with patch('dft_to_lammps_bridge.read_vasp_out') as mock_read:
                mock_frames = [Mock() for _ in range(count)]
                mock_read.return_value = mock_frames
                
                outcar = tmp_path / f"OUTCAR_{count}"
                outcar.write_text("mock")
                
                start = time.time()
                parser.parse(outcar)
                elapsed = time.time() - start
                times.append(elapsed)
        
        # Check that time scales roughly linearly (within factor of 5)
        if len(times) >= 2:
            ratio = times[-1] / times[0]
            expected_ratio = frame_counts[-1] / frame_counts[0]
            assert ratio < expected_ratio * 5, f"Parser doesn't scale well: {ratio} vs {expected_ratio}"
    
    @pytest.mark.timeout(60)
    def test_msd_scalability(self):
        """Test MSD calculation scalability."""
        from code_templates.md_simulation_lammps import MDAnalyzer
        
        frame_counts = [100, 500, 1000]
        times = []
        
        for count in frame_counts:
            mock_frames = []
            for _ in range(count):
                mock_atoms = Mock()
                mock_atoms.get_positions.return_value = np.random.randn(10, 3)
                mock_frames.append(mock_atoms)
            
            analyzer = MDAnalyzer("test")
            analyzer.trajectory = mock_frames
            
            start = time.time()
            times_arr, msd = analyzer.compute_msd(timestep=1.0)
            elapsed = time.time() - start
            times.append(elapsed)
        
        # Should scale roughly linearly
        if len(times) >= 2:
            ratio = times[-1] / times[0]
            expected_ratio = frame_counts[-1] / frame_counts[0]
            assert ratio < expected_ratio * 3, f"MSD doesn't scale well: {ratio} vs {expected_ratio}"


# =============================================================================
# Regression Tests
# =============================================================================

@pytest.mark.benchmark
class TestPerformanceRegression:
    """Tests to detect performance regressions."""
    
    def test_lammps_input_generation_not_slower(self, tmp_path):
        """Ensure LAMMPS input generation hasn't regressed."""
        try:
            from code_templates.md_simulation_lammps import LAMMPSInputGenerator, LAMMPSConfig
            from ase import Atoms
            
            config = LAMMPSConfig()
            generator = LAMMPSInputGenerator(config)
            
            atoms = Atoms('H2', positions=[[0, 0, 0], [1, 0, 0]], cell=[10, 10, 10], pbc=True)
            
            times = []
            for _ in range(10):
                start = time.time()
                with patch('code_templates.md_simulation_lammps.write_lammps_data'):
                    generator.generate_input(atoms)
                times.append(time.time() - start)
            
            avg_time = np.mean(times)
            
            # Should average less than 0.1 seconds per generation
            assert avg_time < 0.1, f"Input generation too slow: {avg_time:.4f}s"
        except ImportError:
            pytest.skip("ASE not available")
    
    def test_scheduler_detection_not_slower(self):
        """Ensure scheduler detection hasn't regressed."""
        from hpc_scheduler import detect_scheduler
        
        times = []
        for _ in range(10):
            start = time.time()
            with patch('subprocess.run') as mock_run:
                mock_run.side_effect = FileNotFoundError()
                detect_scheduler()
            times.append(time.time() - start)
        
        avg_time = np.mean(times)
        
        # Should average less than 0.01 seconds
        assert avg_time < 0.01, f"Scheduler detection too slow: {avg_time:.4f}s"