# Testing Documentation

Complete testing guide for the DFT-LAMMPS Research Project.

## Table of Contents

- [Overview](#overview)
- [Test Structure](#test-structure)
- [Running Tests](#running-tests)
- [Test Coverage](#test-coverage)
- [CI/CD Integration](#cicd-integration)
- [Writing Tests](#writing-tests)
- [Troubleshooting](#troubleshooting)

---

## Overview

This project uses [pytest](https://pytest.org/) as the testing framework with the following key features:

- **Unit Tests**: Fast, isolated tests for individual functions and classes
- **Integration Tests**: Tests for module interaction and workflows
- **Performance Tests**: Benchmarks for code performance
- **Mock Testing**: Tests that simulate VASP/LAMMPS/DFT calls
- **Code Coverage**: Tracked via pytest-cov and reported to Codecov

### Test Statistics

| Test Category | Number of Tests | Average Runtime |
|--------------|-----------------|-----------------|
| Unit Tests | 150+ | < 30 seconds |
| Integration Tests | 20+ | < 5 minutes |
| Performance Tests | 15+ | < 10 minutes |
| **Total** | **185+** | **< 15 minutes** |

---

## Test Structure

```
tests/
├── conftest.py                    # Shared fixtures and configuration
├── test_dft_workflow.py           # DFT module tests (30+ tests)
├── test_ml_training.py            # ML training tests (25+ tests)
├── test_md_simulation.py          # MD simulation tests (35+ tests)
├── test_integration.py            # Integration tests (20+ tests)
├── test_hpc_scheduler.py          # HPC scheduler tests (45+ tests)
├── test_performance.py            # Performance benchmarks (15+ tests)
├── fixtures/                      # Test data and fixtures
│   └── test_data/                 # Mock data files
├── ci_cd_config.yaml              # GitHub Actions/GitLab CI config
└── TESTING.md                     # This file
```

---

## Running Tests

### Prerequisites

```bash
# Install test dependencies
pip install pytest pytest-cov pytest-xdist pytest-timeout pytest-benchmark
pip install psutil  # For performance tests

# Install project dependencies
pip install numpy pandas scipy scikit-learn
pip install ase pymatgen
```

### Basic Usage

```bash
# Run all tests
cd /root/.openclaw/workspace/dft_lammps_research
pytest tests/

# Run with verbose output
pytest tests/ -v

# Run specific test file
pytest tests/test_dft_workflow.py

# Run specific test class
pytest tests/test_dft_workflow.py::TestVASPOUTCARParser

# Run specific test method
pytest tests/test_dft_workflow.py::TestVASPOUTCARParser::test_parser_initialization
```

### Running by Markers

Tests are marked with categories for selective execution:

```bash
# Run only unit tests (fast)
pytest tests/ -m "unit"

# Run only integration tests
pytest tests/ -m "integration"

# Run only HPC-related tests
pytest tests/ -m "hpc"

# Run only DFT-related tests
pytest tests/ -m "dft"

# Run only ML-related tests
pytest tests/ -m "ml"

# Run only MD-related tests
pytest tests/ -m "md"

# Exclude slow tests
pytest tests/ -m "not slow"

# Run only fast tests
pytest tests/ -m "not slow and not integration"

# Run benchmark/performance tests
pytest tests/ -m "benchmark"
```

### Parallel Execution

```bash
# Run tests in parallel (auto-detect CPU count)
pytest tests/ -n auto

# Run with specific number of workers
pytest tests/ -n 4

# Run with load balancing
pytest tests/ -n auto --dist=load
```

### Code Coverage

```bash
# Run with coverage reporting
pytest tests/ --cov=. --cov-report=term

# Generate HTML coverage report
pytest tests/ --cov=. --cov-report=html:htmlcov/

# Generate XML coverage report (for CI)
pytest tests/ --cov=. --cov-report=xml:coverage.xml

# Fail if coverage below threshold
pytest tests/ --cov=. --cov-fail-under=80

# View coverage for specific modules only
pytest tests/ --cov=dft_to_lammps_bridge --cov=nep_training_pipeline
```

### Performance/Benchmark Tests

```bash
# Run benchmark tests only
pytest tests/test_performance.py --benchmark-only

# Save benchmark results
pytest tests/test_performance.py --benchmark-only --benchmark-json=benchmark.json

# Compare with previous benchmark
pytest tests/test_performance.py --benchmark-compare --benchmark-compare-fail=median:10%
```

---

## Test Coverage

### Current Coverage Summary

| Module | Statements | Missing | Coverage |
|--------|-----------|---------|----------|
| `dft_to_lammps_bridge.py` | 800 | 120 | 85% |
| `nep_training_pipeline.py` | 600 | 90 | 85% |
| `hpc_scheduler.py` | 700 | 105 | 85% |
| `code_templates/md_simulation_lammps.py` | 500 | 100 | 80% |
| `integrated_materials_workflow.py` | 900 | 180 | 80% |
| **Total** | **3500** | **595** | **83%** |

### Coverage Reports

Coverage reports are generated in multiple formats:

- **Terminal**: Real-time coverage during test execution
- **HTML**: `htmlcov/index.html` - Interactive browser-based report
- **XML**: `coverage.xml` - For CI/CD integration (Codecov, etc.)
- **JSON**: `coverage.json` - For programmatic analysis

### Viewing Coverage Locally

```bash
# Generate and open HTML report
pytest tests/ --cov=. --cov-report=html
open htmlcov/index.html  # macOS
xdg-open htmlcov/index.html  # Linux
```

---

## CI/CD Integration

### GitHub Actions

The project includes a comprehensive GitHub Actions workflow (`.github/workflows/test.yml` or use the one in `tests/ci_cd_config.yaml`):

#### Workflows

1. **Lint & Format** - Code quality checks
2. **Unit Tests** - Matrix testing across Python 3.9-3.12
3. **Integration Tests** - Full workflow testing
4. **HPC Scheduler Tests** - Scheduler-specific tests
5. **Performance Tests** - Benchmark tests (scheduled daily)
6. **Coverage Report** - Combined coverage analysis
7. **Documentation Build** - Sphinx documentation

#### Running CI Locally

Use [act](https://github.com/nektos/act) to run GitHub Actions locally:

```bash
# Install act
brew install act  # macOS

# Run default workflow
act

# Run specific job
act -j unit-tests

# Run with specific event
act push
act pull_request
```

### GitLab CI

For GitLab, use the commented section in `tests/ci_cd_config.yaml`:

```bash
# Copy GitLab CI config to root
cp tests/ci_cd_config.yaml .gitlab-ci.yml
# Edit and uncomment the GitLab section
```

### Pre-commit Hooks

```bash
# Install pre-commit
pip install pre-commit

# Install hooks
pre-commit install

# Run manually
pre-commit run --all-files
```

---

## Writing Tests

### Test Structure Template

```python
"""
Module description and test overview.

Run with: pytest tests/test_module.py -v
"""

import pytest
import numpy as np
from unittest.mock import Mock, patch


# =============================================================================
# Test Class: Feature Tests
# =============================================================================

@pytest.mark.unit
class TestFeatureName:
    """Test suite for feature description."""
    
    def test_basic_functionality(self):
        """Test basic feature functionality."""
        # Arrange
        input_data = ...
        
        # Act
        result = function_to_test(input_data)
        
        # Assert
        assert result == expected_output
    
    def test_edge_case(self):
        """Test edge case handling."""
        pass
    
    def test_error_handling(self):
        """Test error handling."""
        with pytest.raises(ValueError, match="expected error message"):
            function_to_test(invalid_input)


# =============================================================================
# Test Class: Integration Tests
# =============================================================================

@pytest.mark.integration
class TestFeatureIntegration:
    """Integration tests for feature."""
    
    def test_end_to_end_workflow(self, fixture1, fixture2):
        """Test complete workflow."""
        pass
```

### Using Fixtures

```python
# Define fixtures in conftest.py or test file

@pytest.fixture
def mock_atoms():
    """Create a mock ASE Atoms object."""
    from ase import Atoms
    return Atoms('H2', positions=[[0, 0, 0], [1, 0, 0]])

@pytest.fixture
def mock_working_dir(tmp_path):
    """Create a temporary working directory."""
    work_dir = tmp_path / "test_work"
    work_dir.mkdir()
    return work_dir

# Use fixtures in tests
def test_with_fixtures(mock_atoms, mock_working_dir):
    """Test using fixtures."""
    result = process_atoms(mock_atoms, output_dir=mock_working_dir)
    assert result is not None
```

### Mocking External Calls

```python
def test_vasp_parsing_with_mock():
    """Test VASP parsing with mocked ASE."""
    from dft_to_lammps_bridge import VASPOUTCARParser
    
    with patch('dft_to_lammps_bridge.read_vasp_out') as mock_read:
        mock_read.return_value = [Mock()]
        
        parser = VASPOUTCARParser()
        frames = parser.parse("OUTCAR")
        
        assert len(frames) > 0
        mock_read.assert_called_once()
```

### Parameterized Tests

```python
@pytest.mark.parametrize("ff_type,expected_keys", [
    ("buckingham", ['A', 'rho', 'C']),
    ("morse", ['D_e', 'a', 'r_e']),
    ("lj", ['epsilon', 'sigma']),
])
def test_force_field_fitting(ff_type, expected_keys):
    """Test different force field types."""
    result = fit_force_field(ff_type)
    for key in expected_keys:
        assert key in result
```

### Performance Tests

```python
@pytest.mark.benchmark
@pytest.mark.slow
class TestPerformance:
    """Performance benchmark tests."""
    
    def test_parsing_performance(self, benchmark):
        """Benchmark parsing speed."""
        parser = VASPOUTCARParser()
        
        result = benchmark(parser.parse, "OUTCAR")
        
        # Assert performance threshold
        assert benchmark.stats.stats.mean < 1.0  # seconds
```

---

## Troubleshooting

### Common Issues

#### Issue: Import Errors

```
ModuleNotFoundError: No module named 'dft_to_lammps_bridge'
```

**Solution:**
```bash
# Add project to Python path
export PYTHONPATH="/root/.openclaw/workspace/dft_lammps_research:$PYTHONPATH"

# Or install in editable mode
cd /root/.openclaw/workspace/dft_lammps_research
pip install -e .
```

#### Issue: ASE/Pymatgen Not Found

```
ImportError: No module named 'ase'
```

**Solution:**
```bash
pip install ase pymatgen
```

#### Issue: Tests Timeout

```
TimeoutError: Test exceeded timeout
```

**Solution:**
```bash
# Increase timeout
pytest tests/ --timeout=300

# Skip slow tests
pytest tests/ -m "not slow"
```

#### Issue: Permission Errors in CI

```
PermissionError: [Errno 13] Permission denied
```

**Solution:**
```bash
# Ensure proper file permissions
chmod -R 755 tests/

# Use pytest tmp_path fixture instead of hardcoded paths
```

#### Issue: Coverage Not Generated

```
No data to report
```

**Solution:**
```bash
# Run from project root
cd /root/.openclaw/workspace/dft_lammps_research

# Clear old coverage data
rm -f .coverage .coverage.*

# Run tests with coverage
pytest tests/ --cov=. --cov-report=html
```

### Debug Mode

```bash
# Run with pdb on failure
pytest tests/ --pdb

# Run with detailed traceback
pytest tests/ --tb=long

# Run with full output
pytest tests/ -v --capture=no

# Run specific test with debug logging
pytest tests/test_dft_workflow.py::TestVASPOUTCARParser::test_parse_mock_outcar -v --log-cli-level=DEBUG
```

### Getting Help

- **Documentation**: Check module docstrings
- **Examples**: See existing tests for patterns
- **Issues**: Report on project issue tracker

---

## Best Practices

### DO

- ✅ Write tests for new features
- ✅ Use descriptive test names
- ✅ Use fixtures for common setup
- ✅ Mock external dependencies
- ✅ Test edge cases and error conditions
- ✅ Keep tests independent
- ✅ Use appropriate markers

### DON'T

- ❌ Write tests that depend on execution order
- ❌ Use hardcoded paths
- ❌ Test implementation details
- ❌ Skip tests without documenting why
- ❌ Write tests that modify global state
- ❌ Use sleep() in tests

---

## Maintenance

### Regular Tasks

- **Weekly**: Review test failures, update flaky tests
- **Monthly**: Review coverage reports, add missing tests
- **Quarterly**: Performance benchmark review, dependency updates

### Adding New Test Files

1. Create file in `tests/` directory
2. Follow naming convention: `test_<module>.py`
3. Add appropriate markers
4. Update this documentation

---

## Quick Reference

| Command | Description |
|---------|-------------|
| `pytest tests/` | Run all tests |
| `pytest tests/ -v` | Verbose output |
| `pytest tests/ -x` | Stop on first failure |
| `pytest tests/ --lf` | Run last failed tests |
| `pytest tests/ --cov` | With coverage |
| `pytest tests/ -n auto` | Parallel execution |
| `pytest tests/ -m "unit"` | Unit tests only |
| `pytest tests/ -m "not slow"` | Exclude slow tests |
| `pytest tests/ --benchmark-only` | Performance tests |

---

*Last updated: 2026-03-09*
