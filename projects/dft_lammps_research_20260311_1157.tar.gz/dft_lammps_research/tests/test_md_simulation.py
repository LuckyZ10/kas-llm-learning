"""
MD Simulation Tests
===================

Tests for LAMMPS molecular dynamics simulation:
- LAMMPS input generation
- MD simulation execution (mocked)
- Trajectory analysis
- Property calculations (MSD, diffusion, RDF, etc.)

Run with: pytest tests/test_md_simulation.py -v
"""

import os
import sys
import json
import pytest
import numpy as np
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock, mock_open, call
from io import StringIO


# =============================================================================
# Test Class: LAMMPS Input Generator Tests
# =============================================================================

@pytest.mark.unit
@pytest.mark.md
class TestLAMMPSInputGeneratorMD:
    """Test suite for LAMMPS input generation in MD context."""
    
    def test_lammps_config_initialization(self):
        """Test LAMMPS configuration initialization."""
        from code_templates.md_simulation_lammps import LAMMPSConfig
        
        config = LAMMPSConfig(
            pair_style="deepmd",
            potential_file="graph.pb",
            ensemble="nvt",
            temperature=500.0,
            nsteps=10000
        )
        
        assert config.pair_style == "deepmd"
        assert config.potential_file == "graph.pb"
        assert config.ensemble == "nvt"
        assert config.temperature == 500.0
        assert config.nsteps == 10000
    
    def test_input_generator_initialization(self):
        """Test LAMMPS input generator initialization."""
        from code_templates.md_simulation_lammps import LAMMPSInputGenerator, LAMMPSConfig
        
        config = LAMMPSConfig()
        generator = LAMMPSInputGenerator(config)
        
        assert generator.config == config
        assert generator.input_lines == []
    
    def test_generate_input_creates_files(self, mock_working_dir):
        """Test that generate_input creates necessary files."""
        try:
            from code_templates.md_simulation_lammps import LAMMPSInputGenerator, LAMMPSConfig
            from ase import Atoms
            
            config = LAMMPSConfig(working_dir=str(mock_working_dir))
            generator = LAMMPSInputGenerator(config)
            
            atoms = Atoms('H2', positions=[[0, 0, 0], [1, 0, 0]], cell=[10, 10, 10], pbc=True)
            
            with patch('code_templates.md_simulation_lammps.write_lammps_data'):
                input_file = generator.generate_input(atoms, output_file="in.lammps")
            
            assert Path(input_file).exists()
        except ImportError:
            pytest.skip("ASE not available")
    
    def test_add_header(self):
        """Test header addition to input file."""
        from code_templates.md_simulation_lammps import LAMMPSInputGenerator, LAMMPSConfig
        
        config = LAMMPSConfig()
        generator = LAMMPSInputGenerator(config)
        
        generator._add_header()
        
        assert len(generator.input_lines) > 0
        assert "LAMMPS input file" in generator.input_lines[0]
    
    def test_add_units(self):
        """Test units section addition."""
        from code_templates.md_simulation_lammps import LAMMPSInputGenerator, LAMMPSConfig
        
        config = LAMMPSConfig()
        generator = LAMMPSInputGenerator(config)
        
        generator._add_units()
        
        assert any("units metal" in line for line in generator.input_lines)
        assert any("dimension 3" in line for line in generator.input_lines)
    
    def test_add_potential_deepmd(self):
        """Test DeepMD potential setup."""
        from code_templates.md_simulation_lammps import LAMMPSInputGenerator, LAMMPSConfig
        
        config = LAMMPSConfig(pair_style="deepmd", potential_file="graph.pb")
        generator = LAMMPSInputGenerator(config)
        
        generator._add_potential()
        
        assert any("pair_style deepmd" in line for line in generator.input_lines)
        assert any("pair_coeff * *" in line for line in generator.input_lines)
    
    def test_add_potential_snap(self):
        """Test SNAP potential setup."""
        from code_templates.md_simulation_lammps import LAMMPSInputGenerator, LAMMPSConfig
        
        config = LAMMPSConfig(pair_style="snap", potential_file="snap.coeff")
        generator = LAMMPSInputGenerator(config)
        
        generator._add_potential()
        
        assert any("pair_style snap" in line for line in generator.input_lines)
    
    def test_add_potential_tersoff(self):
        """Test Tersoff potential setup."""
        from code_templates.md_simulation_lammps import LAMMPSInputGenerator, LAMMPSConfig
        
        config = LAMMPSConfig(pair_style="tersoff", potential_file="SiC.tersoff")
        generator = LAMMPSInputGenerator(config)
        
        generator._add_potential()
        
        assert any("pair_style tersoff" in line for line in generator.input_lines)
    
    def test_add_potential_eam(self):
        """Test EAM potential setup."""
        from code_templates.md_simulation_lammps import LAMMPSInputGenerator, LAMMPSConfig
        
        config = LAMMPSConfig(pair_style="eam/alloy", potential_file="Cu_u3.eam")
        generator = LAMMPSInputGenerator(config)
        
        generator._add_potential()
        
        assert any("pair_style eam/alloy" in line for line in generator.input_lines)
    
    def test_add_potential_unsupported_raises(self):
        """Test that unsupported pair style raises error."""
        from code_templates.md_simulation_lammps import LAMMPSInputGenerator, LAMMPSConfig
        
        config = LAMMPSConfig(pair_style="unsupported")
        generator = LAMMPSInputGenerator(config)
        
        with pytest.raises(ValueError, match="Unsupported pair style"):
            generator._add_potential()
    
    def test_add_run_nve(self):
        """Test NVE ensemble run commands."""
        from code_templates.md_simulation_lammps import LAMMPSInputGenerator, LAMMPSConfig
        
        config = LAMMPSConfig(ensemble="nve", nsteps=5000)
        generator = LAMMPSInputGenerator(config)
        
        generator._add_run()
        
        assert any("fix ensemble all nve" in line for line in generator.input_lines)
        assert any("run 5000" in line for line in generator.input_lines)
    
    def test_add_run_nvt(self):
        """Test NVT ensemble run commands."""
        from code_templates.md_simulation_lammps import LAMMPSInputGenerator, LAMMPSConfig
        
        config = LAMMPSConfig(ensemble="nvt", temperature=300.0, nsteps=10000)
        generator = LAMMPSInputGenerator(config)
        
        generator._add_run()
        
        assert any("fix ensemble all nvt" in line for line in generator.input_lines)
        assert any("300.0 300.0" in line for line in generator.input_lines)
    
    def test_add_run_npt(self):
        """Test NPT ensemble run commands."""
        from code_templates.md_simulation_lammps import LAMMPSInputGenerator, LAMMPSConfig
        
        config = LAMMPSConfig(
            ensemble="npt",
            temperature=300.0,
            pressure=1.0,
            nsteps=10000
        )
        generator = LAMMPSInputGenerator(config)
        
        generator._add_run()
        
        assert any("fix ensemble all npt" in line for line in generator.input_lines)
    
    def test_add_run_npt_without_pressure_raises(self):
        """Test that NPT without pressure raises error."""
        from code_templates.md_simulation_lammps import LAMMPSInputGenerator, LAMMPSConfig
        
        config = LAMMPSConfig(ensemble="npt", pressure=None)
        generator = LAMMPSInputGenerator(config)
        
        with pytest.raises(ValueError, match="Pressure must be specified"):
            generator._add_run()
    
    def test_add_neighbor(self):
        """Test neighbor list settings."""
        from code_templates.md_simulation_lammps import LAMMPSInputGenerator, LAMMPSConfig
        
        config = LAMMPSConfig()
        generator = LAMMPSInputGenerator(config)
        
        generator._add_neighbor()
        
        assert any("neighbor" in line for line in generator.input_lines)
        assert any("neigh_modify" in line for line in generator.input_lines)
    
    def test_add_constraints(self):
        """Test constraint settings."""
        from code_templates.md_simulation_lammps import LAMMPSInputGenerator, LAMMPSConfig
        
        config = LAMMPSConfig(fix_com=True)
        generator = LAMMPSInputGenerator(config)
        
        generator._add_constraints()
        
        assert any("fix com_fix" in line for line in generator.input_lines)
    
    def test_add_temperature_init(self):
        """Test temperature initialization."""
        from code_templates.md_simulation_lammps import LAMMPSInputGenerator, LAMMPSConfig
        
        config = LAMMPSConfig(temperature=500.0)
        generator = LAMMPSInputGenerator(config)
        
        generator._add_temperature_init()
        
        assert any("velocity all create 500.0" in line for line in generator.input_lines)
    
    def test_add_output(self):
        """Test output settings."""
        from code_templates.md_simulation_lammps import LAMMPSInputGenerator, LAMMPSConfig
        
        config = LAMMPSConfig(
            thermo_interval=100,
            dump_interval=1000,
            dump_file="trajectory.dump"
        )
        generator = LAMMPSInputGenerator(config)
        
        generator._add_output()
        
        assert any("thermo 100" in line for line in generator.input_lines)
        assert any("trajectory.dump" in line for line in generator.input_lines)


# =============================================================================
# Test Class: LAMMPS Simulator Tests
# =============================================================================

@pytest.mark.unit
@pytest.mark.md
class TestLAMMPSSimulator:
    """Test suite for LAMMPS simulator."""
    
    def test_simulator_initialization(self):
        """Test simulator initialization."""
        from code_templates.md_simulation_lammps import LAMMPSSimulator, LAMMPSConfig
        
        config = LAMMPSConfig()
        simulator = LAMMPSSimulator(config)
        
        assert simulator.config == config
        assert simulator.input_generator is not None
    
    def test_run_simulation_mock(self, mock_working_dir):
        """Test simulation execution with mocked subprocess."""
        from code_templates.md_simulation_lammps import LAMMPSSimulator, LAMMPSConfig
        
        config = LAMMPSConfig(working_dir=str(mock_working_dir))
        simulator = LAMMPSSimulator(config)
        
        mock_atoms = Mock()
        input_file = mock_working_dir / "in.lammps"
        input_file.write_text("mock input")
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(returncode=0, stdout="", stderr="")
            
            result = simulator.run_simulation(mock_atoms, input_file=str(input_file))
            
            assert mock_run.called
    
    def test_run_simulation_failure(self, mock_working_dir):
        """Test simulation failure handling."""
        from code_templates.md_simulation_lammps import LAMMPSSimulator, LAMMPSConfig
        
        config = LAMMPSConfig(working_dir=str(mock_working_dir))
        simulator = LAMMPSSimulator(config)
        
        mock_atoms = Mock()
        input_file = mock_working_dir / "in.lammps"
        input_file.write_text("mock input")
        
        with patch('subprocess.run') as mock_run:
            mock_run.side_effect = Exception("LAMMPS failed")
            
            with pytest.raises(Exception):
                simulator.run_simulation(mock_atoms, input_file=str(input_file))
    
    def test_run_optimization_mock(self, mock_working_dir):
        """Test optimization with mocked ASE."""
        try:
            from code_templates.md_simulation_lammps import LAMMPSSimulator, LAMMPSConfig
            from ase import Atoms
            
            config = LAMMPSConfig(working_dir=str(mock_working_dir))
            simulator = LAMMPSSimulator(config)
            
            atoms = Atoms('H2', positions=[[0, 0, 0], [1, 0, 0]], cell=[10, 10, 10], pbc=True)
            
            with patch('ase.optimize.FIRE') as mock_fire:
                mock_optimizer = Mock()
                mock_optimizer.run.return_value = None
                mock_fire.return_value = mock_optimizer
                
                with patch('ase.calculators.lammpsrun.LAMMPS'):
                    result = simulator.run_optimization(atoms, fmax=0.01)
                    
                    assert result is not None
        except ImportError:
            pytest.skip("ASE not available")
    
    def test_get_type_map(self, mock_working_dir):
        """Test getting element type map."""
        try:
            from code_templates.md_simulation_lammps import LAMMPSSimulator, LAMMPSConfig
            from ase import Atoms
            
            config = LAMMPSConfig()
            simulator = LAMMPSSimulator(config)
            
            atoms = Atoms('Li2S', positions=[[0, 0, 0], [1, 0, 0], [0.5, 1, 0]], cell=[5, 5, 5], pbc=True)
            
            type_map = simulator._get_type_map(atoms)
            
            assert 'Li' in type_map
            assert 'S' in type_map
        except ImportError:
            pytest.skip("ASE not available")


# =============================================================================
# Test Class: MD Analyzer Tests
# =============================================================================

@pytest.mark.unit
@pytest.mark.md
class TestMDAnalyzer:
    """Test suite for MD trajectory analysis."""
    
    def test_analyzer_initialization(self):
        """Test analyzer initialization."""
        from code_templates.md_simulation_lammps import MDAnalyzer
        
        analyzer = MDAnalyzer("trajectory.dump")
        
        assert analyzer.trajectory_file == "trajectory.dump"
        assert analyzer.trajectory is None
    
    def test_read_trajectory_mock(self):
        """Test trajectory reading with mock."""
        from code_templates.md_simulation_lammps import MDAnalyzer
        
        analyzer = MDAnalyzer("trajectory.dump")
        
        mock_frames = [Mock(), Mock(), Mock()]
        with patch('code_templates.md_simulation_lammps.read') as mock_read:
            mock_read.return_value = mock_frames
            
            frames = analyzer.read_trajectory()
            
            assert len(frames) == 3
            assert analyzer.trajectory == mock_frames
    
    def test_compute_msd(self):
        """Test mean squared displacement calculation."""
        from code_templates.md_simulation_lammps import MDAnalyzer
        
        analyzer = MDAnalyzer("trajectory.dump")
        
        # Create mock trajectory
        mock_frames = []
        for i in range(10):
            mock_atoms = Mock()
            mock_atoms.get_positions.return_value = np.array([
                [0.0 + i*0.1, 0.0, 0.0],
                [1.0 + i*0.1, 0.0, 0.0]
            ])
            mock_frames.append(mock_atoms)
        
        analyzer.trajectory = mock_frames
        
        times, msd = analyzer.compute_msd(timestep=1.0)
        
        assert len(times) == len(msd)
        assert len(times) == 10
        assert msd[-1] > msd[0]  # MSD should increase
    
    def test_compute_msd_with_atom_type(self):
        """Test MSD calculation for specific atom type."""
        from code_templates.md_simulation_lammps import MDAnalyzer
        
        analyzer = MDAnalyzer("trajectory.dump")
        
        mock_frames = []
        for i in range(5):
            mock_atoms = Mock()
            mock_atoms.get_positions.return_value = np.array([
                [0.0 + i*0.1, 0.0, 0.0],
                [1.0, 0.0, 0.0]
            ])
            mock_atoms.get_chemical_symbols.return_value = ['Li', 'S']
            mock_frames.append(mock_atoms)
        
        analyzer.trajectory = mock_frames
        
        times, msd = analyzer.compute_msd(atom_type='Li', timestep=1.0)
        
        assert len(times) == 5
    
    def test_compute_diffusion_coefficient(self):
        """Test diffusion coefficient calculation."""
        from code_templates.md_simulation_lammps import MDAnalyzer
        
        analyzer = MDAnalyzer("trajectory.dump")
        
        # Create mock trajectory with diffusive motion
        mock_frames = []
        np.random.seed(42)
        for i in range(100):
            mock_atoms = Mock()
            # Random walk
            positions = np.cumsum(np.random.randn(2, 3) * 0.01, axis=0)
            mock_atoms.get_positions.return_value = positions
            mock_frames.append(mock_atoms)
        
        analyzer.trajectory = mock_frames
        
        D = analyzer.compute_diffusion_coefficient(
            start_frame=10,
            end_frame=100,
            timestep=1.0
        )
        
        assert isinstance(D, float)
        assert D >= 0  # Diffusion coefficient should be positive
    
    def test_compute_temperature(self):
        """Test temperature calculation from velocities."""
        from code_templates.md_simulation_lammps import MDAnalyzer
        
        analyzer = MDAnalyzer("trajectory.dump")
        
        mock_frames = []
        for _ in range(5):
            mock_atoms = Mock()
            mock_atoms.get_velocities.return_value = np.random.randn(10, 3) * 100
            mock_atoms.get_masses.return_value = np.ones(10)
            mock_frames.append(mock_atoms)
        
        analyzer.trajectory = mock_frames
        
        temperatures = analyzer.compute_temperature()
        
        assert len(temperatures) == 5
        assert all(t > 0 for t in temperatures)
    
    def test_compute_density(self):
        """Test density calculation."""
        from code_templates.md_simulation_lammps import MDAnalyzer
        
        analyzer = MDAnalyzer("trajectory.dump")
        
        mock_frames = []
        for _ in range(3):
            mock_atoms = Mock()
            mock_atoms.get_masses.return_value = np.array([6.94, 6.94, 32.06])  # 2 Li + 1 S
            mock_atoms.get_volume.return_value = 100.0  # Å³
            mock_frames.append(mock_atoms)
        
        analyzer.trajectory = mock_frames
        
        densities = analyzer.compute_density()
        
        assert len(densities) == 3
        assert all(d > 0 for d in densities)
    
    def test_compute_pressure(self):
        """Test pressure calculation."""
        from code_templates.md_simulation_lammps import MDAnalyzer
        
        analyzer = MDAnalyzer("trajectory.dump")
        
        mock_frames = []
        for _ in range(3):
            mock_atoms = Mock()
            # Stress tensor in Voigt notation
            mock_atoms.get_stress.return_value = np.array([0.1, 0.1, 0.1, 0.0, 0.0, 0.0])
            mock_frames.append(mock_atoms)
        
        analyzer.trajectory = mock_frames
        
        pressures = analyzer.compute_pressure()
        
        assert len(pressures) == 3
    
    def test_compute_ionic_conductivity(self):
        """Test ionic conductivity calculation."""
        from code_templates.md_simulation_lammps import MDAnalyzer
        
        analyzer = MDAnalyzer("trajectory.dump")
        
        # Mock trajectory with Li diffusion
        mock_frames = []
        np.random.seed(42)
        for i in range(50):
            mock_atoms = Mock()
            # Li diffusing, S fixed
            li_pos = np.cumsum(np.random.randn(1, 3) * 0.01, axis=0)
            s_pos = np.array([[1.0, 1.0, 1.0]])
            mock_atoms.get_positions.return_value = np.vstack([li_pos, s_pos])
            mock_atoms.get_chemical_symbols.return_value = ['Li', 'S']
            mock_atoms.get_volume.return_value = 1000.0
            mock_frames.append(mock_atoms)
        
        analyzer.trajectory = mock_frames
        
        # Mock compute_diffusion_coefficient
        with patch.object(analyzer, 'compute_diffusion_coefficient') as mock_D:
            mock_D.return_value = 1e-5  # cm²/s
            
            sigma = analyzer.compute_ionic_conductivity(
                charges={'Li': 1.0, 'S': -2.0},
                temperature=300.0,
                timestep=1.0
            )
            
            assert isinstance(sigma, float)
            assert sigma >= 0
    
    def test_compute_number_density(self):
        """Test number density calculation."""
        from code_templates.md_simulation_lammps import MDAnalyzer
        
        analyzer = MDAnalyzer("trajectory.dump")
        
        mock_atoms = Mock()
        mock_atoms.get_chemical_symbols.return_value = ['Li', 'Li', 'S']
        mock_atoms.get_volume.return_value = 1000.0  # Å³
        
        analyzer.trajectory = [mock_atoms]
        
        n = analyzer._compute_number_density('Li')
        
        assert isinstance(n, float)
        assert n > 0
    
    def test_generate_report(self, mock_working_dir):
        """Test analysis report generation."""
        from code_templates.md_simulation_lammps import MDAnalyzer
        
        analyzer = MDAnalyzer("trajectory.dump")
        
        mock_frames = []
        for _ in range(10):
            mock_atoms = Mock()
            mock_atoms.get_masses.return_value = np.ones(10)
            mock_atoms.get_volume.return_value = 1000.0
            mock_atoms.get_chemical_symbols.return_value = ['Li'] * 10
            mock_frames.append(mock_atoms)
        
        analyzer.trajectory = mock_frames
        
        output_file = mock_working_dir / "report.json"
        report = analyzer.generate_report(str(output_file))
        
        assert output_file.exists()
        assert 'trajectory_file' in report
        assert 'n_frames' in report
        assert 'properties' in report
    
    def test_compute_rdf_mock(self):
        """Test RDF calculation with mock."""
        from code_templates.md_simulation_lammps import MDAnalyzer
        
        analyzer = MDAnalyzer("trajectory.dump")
        
        mock_frames = []
        for _ in range(5):
            mock_atoms = Mock()
            mock_atoms.get_chemical_symbols.return_value = ['Li', 'Li', 'S']
            mock_frames.append(mock_atoms)
        
        analyzer.trajectory = mock_frames
        
        with patch('code_templates.md_simulation_lammps.Analysis') as mock_analysis:
            mock_anal = Mock()
            mock_anal.get_rdf.return_value = np.ones(100)
            mock_analysis.return_value = mock_anal
            
            rdf_data = analyzer.compute_rdf(
                rmax=10.0,
                nbins=100,
                element_pairs=[('Li', 'S')]
            )
            
            assert ('Li', 'S') in rdf_data


# =============================================================================
# Test Class: MD Simulation Workflow Tests
# =============================================================================

@pytest.mark.integration
@pytest.mark.md
class TestMDSimulationWorkflow:
    """Test suite for complete MD simulation workflow."""
    
    def test_workflow_initialization(self):
        """Test workflow initialization."""
        from code_templates.md_simulation_lammps import MDSimulationWorkflow, LAMMPSConfig
        
        config = LAMMPSConfig()
        workflow = MDSimulationWorkflow(config)
        
        assert workflow.config == config
        assert workflow.simulator is not None
    
    def test_equilibration_run(self, mock_working_dir):
        """Test equilibration run with mocks."""
        from code_templates.md_simulation_lammps import MDSimulationWorkflow, LAMMPSConfig
        
        config = LAMMPSConfig(working_dir=str(mock_working_dir))
        workflow = MDSimulationWorkflow(config)
        
        mock_atoms = Mock()
        
        with patch.object(workflow.simulator, 'run_simulation') as mock_run:
            with patch('code_templates.md_simulation_lammps.read') as mock_read:
                mock_read.return_value = Mock()
                
                result = workflow.equilibration_run(
                    mock_atoms,
                    nvt_steps=100,
                    npt_steps=0
                )
                
                assert mock_run.called
    
    def test_production_run(self, mock_working_dir):
        """Test production run with mocks."""
        from code_templates.md_simulation_lammps import MDSimulationWorkflow, LAMMPSConfig
        
        config = LAMMPSConfig(working_dir=str(mock_working_dir))
        workflow = MDSimulationWorkflow(config)
        
        mock_atoms = Mock()
        
        with patch.object(workflow.simulator, 'run_simulation') as mock_run:
            mock_run.return_value = "trajectory.dump"
            
            result = workflow.production_run(mock_atoms, nsteps=1000)
            
            assert result == "trajectory.dump"
    
    def test_full_workflow(self, mock_working_dir):
        """Test complete workflow execution."""
        from code_templates.md_simulation_lammps import MDSimulationWorkflow, LAMMPSConfig
        
        config = LAMMPSConfig(working_dir=str(mock_working_dir))
        workflow = MDSimulationWorkflow(config)
        
        mock_atoms = Mock()
        
        with patch.object(workflow, 'equilibration_run') as mock_equil:
            with patch.object(workflow, 'production_run') as mock_prod:
                with patch('code_templates.md_simulation_lammps.MDAnalyzer') as mock_analyzer:
                    mock_equil.return_value = Mock()
                    mock_prod.return_value = "trajectory.dump"
                    mock_analyzer_instance = Mock()
                    mock_analyzer_instance.generate_report.return_value = {'test': 'report'}
                    mock_analyzer.return_value = mock_analyzer_instance
                    
                    result = workflow.full_workflow(mock_atoms)
                    
                    assert 'trajectory' in result
                    assert 'report' in result


# =============================================================================
# Standalone Test Functions
# =============================================================================

@pytest.mark.unit
def test_lammps_config_defaults():
    """Test LAMMPS configuration defaults."""
    from code_templates.md_simulation_lammps import LAMMPSConfig
    
    config = LAMMPSConfig()
    
    assert config.pair_style == "deepmd"
    assert config.units == "metal"
    assert config.ensemble == "nvt"
    assert config.timestep == 1.0
    assert config.fix_com is True


@pytest.mark.unit
def test_lammps_config_custom_values():
    """Test LAMMPS configuration with custom values."""
    from code_templates.md_simulation_lammps import LAMMPSConfig
    
    config = LAMMPSConfig(
        pair_style="tersoff",
        ensemble="npt",
        temperature=1000.0,
        pressure=10.0,
        timestep=0.5,
        nsteps=50000,
        nprocs=8
    )
    
    assert config.pair_style == "tersoff"
    assert config.ensemble == "npt"
    assert config.temperature == 1000.0
    assert config.pressure == 10.0
    assert config.timestep == 0.5
    assert config.nsteps == 50000
    assert config.nprocs == 8