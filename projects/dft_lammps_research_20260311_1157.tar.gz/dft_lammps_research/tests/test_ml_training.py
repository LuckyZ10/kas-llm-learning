"""
ML Training Pipeline Tests
==========================

Tests for NEP (Neural Evolution Potential) training pipeline:
- NEP data preparation
- NEP input generation
- NEP training workflow
- Model validation

Run with: pytest tests/test_ml_training.py -v
"""

import os
import sys
import json
import pytest
import numpy as np
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock, mock_open
from io import StringIO


# =============================================================================
# Test Class: NEP Data Preparer Tests
# =============================================================================

@pytest.mark.unit
@pytest.mark.ml
class TestNEPDataPreparer:
    """Test suite for NEP data preparation."""
    
    def test_preparer_initialization(self, mock_nep_data_config):
        """Test NEP data preparer initialization."""
        from nep_training_pipeline import NEPDataPreparer
        
        preparer = NEPDataPreparer(mock_nep_data_config)
        
        assert preparer.config == mock_nep_data_config
        assert preparer.frames == []
    
    def test_preparer_default_config(self):
        """Test preparer with default configuration."""
        from nep_training_pipeline import NEPDataPreparer, NEPDataConfig
        
        preparer = NEPDataPreparer()
        
        assert isinstance(preparer.config, NEPDataConfig)
        assert preparer.config.train_ratio == 0.9
    
    def test_extract_frame_data(self, mock_nep_preparer, mock_atoms):
        """Test extracting frame data from atoms."""
        # Add calculator mock
        mock_atoms.calc = Mock()
        mock_atoms.calc.get_potential_energy.return_value = -100.0
        mock_atoms.calc.get_forces.return_value = np.random.randn(6, 3) * 0.1
        
        frame = mock_nep_preparer._extract_frame_data(mock_atoms)
        
        assert frame is not None
        assert 'atoms' in frame
        assert 'symbols' in frame
        assert 'positions' in frame
    
    def test_extract_frame_data_no_calc(self, mock_nep_preparer, mock_atoms):
        """Test extracting frame data without calculator."""
        mock_atoms.calc = None
        mock_atoms.info['energy'] = -100.0
        mock_atoms.arrays['forces'] = np.random.randn(6, 3) * 0.1
        
        frame = mock_nep_preparer._extract_frame_data(mock_atoms)
        
        assert frame is not None
    
    def test_filter_frames_by_energy(self, mock_nep_preparer):
        """Test filtering frames by energy threshold."""
        frames = [
            {'energy': -100.0, 'atoms': Mock(), 'forces': np.random.randn(6, 3) * 0.1},
            {'energy': -100.5, 'atoms': Mock(), 'forces': np.random.randn(6, 3) * 0.1},
            {'energy': 500.0, 'atoms': Mock(), 'forces': np.random.randn(6, 3) * 0.1},  # Outlier
        ]
        
        filtered = mock_nep_preparer.filter_frames(frames)
        
        assert len(filtered) <= len(frames)
    
    def test_filter_frames_by_force(self, mock_nep_preparer):
        """Test filtering frames by force threshold."""
        frames = [
            {'energy': -100.0, 'atoms': Mock(), 'forces': np.random.randn(6, 3) * 0.1},
            {'energy': -100.5, 'atoms': Mock(), 'forces': np.random.randn(6, 3) * 100},  # Large forces
        ]
        
        filtered = mock_nep_preparer.filter_frames(frames)
        
        assert len(filtered) <= len(frames)
    
    def test_write_xyz(self, mock_nep_preparer, mock_working_dir, mock_trajectory):
        """Test writing extended XYZ file."""
        output_file = mock_working_dir / "test.xyz"
        
        frames = []
        for atoms in mock_trajectory:
            frame = mock_nep_preparer._extract_frame_data(atoms)
            if frame:
                frames.append(frame)
        
        mock_nep_preparer._write_xyz(output_file, frames)
        
        assert output_file.exists()
        content = output_file.read_text()
        assert "Lattice=" in content
        assert "Properties=" in content
    
    def test_get_statistics(self, mock_nep_preparer):
        """Test getting statistics from loaded frames."""
        mock_nep_preparer.frames = [
            {
                'energy': -100.0,
                'forces': np.random.randn(6, 3) * 0.1,
                'atoms': Mock(get_chemical_symbols=Mock(return_value=['Li', 'Li', 'S', 'S', 'P', 'P']))
            }
        ]
        
        stats = mock_nep_preparer.get_statistics()
        
        assert 'n_frames' in stats
        assert stats['n_frames'] == 1
    
    def test_get_statistics_empty(self, mock_nep_preparer):
        """Test getting statistics with no frames."""
        stats = mock_nep_preparer.get_statistics()
        
        assert stats == {}
    
    @pytest.mark.slow
    def test_load_vasp_outcar(self, mock_nep_preparer, mock_working_dir, mock_outcar_content):
        """Test loading data from VASP OUTCAR."""
        outcar_path = mock_working_dir / "OUTCAR"
        outcar_path.write_text(mock_outcar_content)
        
        with patch('nep_training_pipeline.read_vasp_out') as mock_read:
            mock_atoms = Mock()
            mock_atoms.get_chemical_symbols.return_value = ['Li', 'S']
            mock_atoms.get_positions.return_value = np.random.randn(2, 3)
            mock_atoms.get_cell.return_value = np.eye(3) * 10
            mock_atoms.get_pbc.return_value = [True, True, True]
            mock_atoms.calc = Mock()
            mock_atoms.calc.get_potential_energy.return_value = -100.0
            mock_atoms.calc.get_forces.return_value = np.random.randn(2, 3) * 0.1
            
            mock_read.return_value = [mock_atoms]
            
            frames = mock_nep_preparer.load_vasp_outcar(outcar_path)
            
            assert isinstance(frames, list)
    
    def test_load_trajectory(self, mock_nep_preparer, mock_working_dir):
        """Test loading from trajectory file."""
        traj_path = mock_working_dir / "trajectory.xyz"
        traj_path.write_text("2\nTest\nH 0 0 0\nH 1 0 0\n")
        
        with patch('nep_training_pipeline.read') as mock_read:
            mock_atoms = Mock()
            mock_atoms.calc = Mock()
            mock_atoms.calc.get_potential_energy.return_value = -10.0
            mock_atoms.calc.get_forces.return_value = np.random.randn(2, 3) * 0.01
            mock_read.return_value = [mock_atoms]
            
            frames = mock_nep_preparer.load_trajectory(traj_path)
            
            assert isinstance(frames, list)
    
    def test_prepare_dataset_no_data_raises(self, mock_nep_preparer, mock_working_dir):
        """Test that preparing dataset with no data raises error."""
        with pytest.raises(ValueError, match="No data loaded"):
            mock_nep_preparer.prepare_dataset(mock_working_dir)


# =============================================================================
# Test Class: NEP Input Generator Tests
# =============================================================================

@pytest.mark.unit
@pytest.mark.ml
class TestNEPInputGenerator:
    """Test suite for NEP input file generation."""
    
    def test_generator_initialization(self, mock_nep_model_config):
        """Test NEP input generator initialization."""
        from nep_training_pipeline import NEPInputGenerator
        
        generator = NEPInputGenerator(mock_nep_model_config)
        
        assert generator.config == mock_nep_model_config
    
    def test_generate_nep_in(self, mock_nep_input_generator, mock_working_dir):
        """Test generating nep.in file."""
        output_file = mock_working_dir / "nep.in"
        
        result = mock_nep_input_generator.generate(str(output_file))
        
        assert Path(result).exists()
        content = output_file.read_text()
        assert "type" in content
        assert "cutoff" in content
        assert "neuron" in content
    
    def test_generate_version_4(self, mock_nep_input_generator, mock_working_dir):
        """Test generating NEP version 4 config."""
        mock_nep_input_generator.config.version = 4
        mock_nep_input_generator.config.basis_size_radial = 8
        mock_nep_input_generator.config.basis_size_angular = 8
        
        output_file = mock_working_dir / "nep_v4.in"
        mock_nep_input_generator.generate(str(output_file))
        
        content = output_file.read_text()
        assert "version 4" in content
        assert "basis_size" in content
    
    def test_generate_with_lmax(self, mock_nep_input_generator, mock_working_dir):
        """Test generating config with l_max settings."""
        mock_nep_input_generator.config.l_max_3body = 4
        mock_nep_input_generator.config.l_max_4body = 2
        mock_nep_input_generator.config.l_max_5body = 0
        
        output_file = mock_working_dir / "nep_lmax.in"
        mock_nep_input_generator.generate(str(output_file))
        
        content = output_file.read_text()
        assert "l_max 4 2" in content
    
    def test_generate_from_preset_fast(self, mock_nep_input_generator, mock_working_dir):
        """Test generating from 'fast' preset."""
        output_file = mock_working_dir / "nep_fast.in"
        
        result = mock_nep_input_generator.generate_from_preset(
            preset="fast",
            type_list=['Li', 'S'],
            output_file=str(output_file)
        )
        
        assert Path(result).exists()
        content = output_file.read_text()
        assert "version 3" in content
    
    def test_generate_from_preset_accurate(self, mock_nep_input_generator, mock_working_dir):
        """Test generating from 'accurate' preset."""
        output_file = mock_working_dir / "nep_accurate.in"
        
        result = mock_nep_input_generator.generate_from_preset(
            preset="accurate",
            type_list=['Li', 'S'],
            output_file=str(output_file)
        )
        
        assert Path(result).exists()
        content = output_file.read_text()
        assert "version 4" in content
    
    def test_generate_from_preset_light(self, mock_nep_input_generator, mock_working_dir):
        """Test generating from 'light' preset."""
        output_file = mock_working_dir / "nep_light.in"
        
        result = mock_nep_input_generator.generate_from_preset(
            preset="light",
            type_list=['Li', 'S'],
            output_file=str(output_file)
        )
        
        assert Path(result).exists()
        content = output_file.read_text()
        assert "neuron 5" in content
    
    def test_generate_from_preset_invalid(self, mock_nep_input_generator, mock_working_dir):
        """Test that invalid preset raises error."""
        with pytest.raises(ValueError, match="Unknown preset"):
            mock_nep_input_generator.generate_from_preset(
                preset="invalid",
                type_list=['Li', 'S']
            )


# =============================================================================
# Test Class: NEP Trainer Tests
# =============================================================================

@pytest.mark.unit
@pytest.mark.ml
class TestNEPTrainer:
    """Test suite for NEP training."""
    
    def test_trainer_initialization(self, mock_nep_training_config):
        """Test NEP trainer initialization."""
        from nep_training_pipeline import NEPTrainer
        
        trainer = NEPTrainer(mock_nep_training_config)
        
        assert trainer.config == mock_nep_training_config
        assert trainer.training_log == []
    
    def test_trainer_creates_working_dir(self, mock_working_dir):
        """Test that trainer creates working directory."""
        from nep_training_pipeline import NEPTrainer, NEPTrainingConfig
        
        new_dir = mock_working_dir / "new_training"
        config = NEPTrainingConfig(working_dir=str(new_dir))
        
        trainer = NEPTrainer(config)
        
        assert new_dir.exists()
    
    def test_setup_training_environment(self, mock_nep_training_config, mock_working_dir):
        """Test setting up training environment."""
        from nep_training_pipeline import NEPTrainer, NEPModelConfig
        
        trainer = NEPTrainer(mock_nep_training_config)
        
        # Create mock data files
        train_xyz = mock_working_dir / "train.xyz"
        test_xyz = mock_working_dir / "test.xyz"
        train_xyz.write_text("2\nTest\nLi 0 0 0\nS 1 0 0\n")
        test_xyz.write_text("2\nTest\nLi 0 0 0\nS 1 0 0\n")
        
        model_config = NEPModelConfig(type_list=['Li', 'S'])
        
        trainer.setup(model_config, str(train_xyz), str(test_xyz))
        
        assert (Path(mock_nep_training_config.working_dir) / "train.xyz").exists()
        assert (Path(mock_nep_training_config.working_dir) / "test.xyz").exists()
        assert (Path(mock_nep_training_config.working_dir) / "nep.in").exists()
    
    def test_setup_missing_train_file_raises(self, mock_nep_training_config, mock_working_dir):
        """Test that missing training file raises error."""
        from nep_training_pipeline import NEPTrainer, NEPModelConfig
        
        trainer = NEPTrainer(mock_nep_training_config)
        model_config = NEPModelConfig(type_list=['Li', 'S'])
        
        with pytest.raises(FileNotFoundError):
            trainer.setup(model_config, "/nonexistent/train.xyz", "/nonexistent/test.xyz")
    
    def test_get_loss_history_empty(self, mock_nep_training_config):
        """Test getting loss history when file doesn't exist."""
        from nep_training_pipeline import NEPTrainer
        
        trainer = NEPTrainer(mock_nep_training_config)
        
        df = trainer.get_loss_history()
        
        assert df.empty
    
    def test_get_loss_history_with_data(self, mock_nep_training_config):
        """Test parsing loss history from file."""
        from nep_training_pipeline import NEPTrainer
        import pandas as pd
        
        trainer = NEPTrainer(mock_nep_training_config)
        
        # Create mock loss.out file
        loss_file = Path(mock_nep_training_config.working_dir) / "loss.out"
        loss_file.write_text("""# generation L1_train L2_train
100 0.1 0.05
200 0.08 0.04
300 0.06 0.03
""")
        
        df = trainer.get_loss_history()
        
        assert not df.empty
        assert 'generation' in df.columns


# =============================================================================
# Test Class: NEP Validator Tests
# =============================================================================

@pytest.mark.unit
@pytest.mark.ml
class TestNEPValidator:
    """Test suite for NEP model validation."""
    
    def test_validator_initialization(self, mock_working_dir):
        """Test validator initialization."""
        from nep_training_pipeline import NEPValidator
        
        model_file = mock_working_dir / "nep.txt"
        model_file.write_text("mock model")
        
        validator = NEPValidator(str(model_file))
        
        assert validator.model_file == model_file
    
    def test_validator_missing_model_raises(self, mock_working_dir):
        """Test that missing model file raises error."""
        from nep_training_pipeline import NEPValidator
        
        with pytest.raises(FileNotFoundError):
            NEPValidator("/nonexistent/nep.txt")
    
    def test_export_to_lammps(self, mock_working_dir):
        """Test exporting model to LAMMPS format."""
        from nep_training_pipeline import NEPValidator
        
        model_file = mock_working_dir / "nep.txt"
        model_file.write_text("mock nep model")
        
        validator = NEPValidator(str(model_file))
        output_file = mock_working_dir / "nep_lammps.txt"
        
        result = validator.export_to_lammps(str(output_file))
        
        assert Path(result).exists()
    
    def test_validate_with_energies(self, mock_working_dir):
        """Test validation with energy comparison."""
        from nep_training_pipeline import NEPValidator
        
        model_file = mock_working_dir / "nep.txt"
        model_file.write_text("mock model")
        
        validator = NEPValidator(str(model_file))
        
        # Mock prediction results
        with patch.object(validator, 'predict') as mock_predict:
            mock_predict.return_value = {
                'energy': [-100.0, -99.5, -99.0]
            }
            
            dft_energies = np.array([-100.1, -99.6, -99.1])
            
            metrics = validator.validate("test.xyz", dft_energies=dft_energies)
            
            assert 'energy' in metrics
            assert 'rmse' in metrics['energy']
            assert 'mae' in metrics['energy']


# =============================================================================
# Test Class: NEP Active Learning Tests
# =============================================================================

@pytest.mark.unit
@pytest.mark.ml
class TestNEPActiveLearning:
    """Test suite for NEP active learning workflow."""
    
    def test_active_learning_initialization(self, mock_nep_training_config):
        """Test active learning initialization."""
        from nep_training_pipeline import NEPActiveLearning, NEPTrainer
        
        trainer = NEPTrainer(mock_nep_training_config)
        al = NEPActiveLearning(trainer, uncertainty_threshold=0.3)
        
        assert al.trainer == trainer
        assert al.uncertainty_threshold == 0.3
        assert al.iteration == 0
    
    def test_estimate_uncertainty(self, mock_nep_training_config):
        """Test uncertainty estimation."""
        from nep_training_pipeline import NEPActiveLearning, NEPTrainer
        
        trainer = NEPTrainer(mock_nep_training_config)
        al = NEPActiveLearning(trainer)
        
        mock_atoms = Mock()
        uncertainty = al._estimate_uncertainty(mock_atoms, "model.txt")
        
        assert isinstance(uncertainty, float)
        assert 0 <= uncertainty <= 1
    
    def test_check_convergence(self, mock_nep_training_config):
        """Test convergence checking."""
        from nep_training_pipeline import NEPActiveLearning, NEPTrainer
        
        trainer = NEPTrainer(mock_nep_training_config)
        al = NEPActiveLearning(trainer)
        
        # Default implementation returns False
        converged = al._check_convergence()
        
        assert converged is False


# =============================================================================
# Test Class: NEP Training Pipeline Integration
# =============================================================================

@pytest.mark.integration
@pytest.mark.ml
class TestNEPTrainingPipeline:
    """Test suite for complete NEP training pipeline."""
    
    def test_pipeline_initialization(self, mock_working_dir):
        """Test pipeline initialization."""
        from nep_training_pipeline import NEPTrainingPipeline
        
        pipeline = NEPTrainingPipeline(working_dir=str(mock_working_dir))
        
        assert pipeline.working_dir == mock_working_dir
        assert pipeline.data_preparer is None
        assert pipeline.trainer is None
    
    def test_pipeline_full_run_mock(self, mock_working_dir):
        """Test full pipeline execution with mocked components."""
        from nep_training_pipeline import NEPTrainingPipeline
        
        pipeline = NEPTrainingPipeline(working_dir=str(mock_working_dir))
        
        # Create mock OUTCAR
        outcar = mock_working_dir / "OUTCAR"
        outcar.write_text("mock outcar")
        
        with patch.object(pipeline, 'data_preparer') as mock_preparer:
            with patch.object(pipeline, 'trainer') as mock_trainer:
                with patch.object(pipeline, 'validator') as mock_validator:
                    mock_preparer.prepare_dataset.return_value = ("train.xyz", "test.xyz")
                    mock_preparer.get_statistics.return_value = {'n_frames': 10}
                    mock_trainer.train.return_value = "nep.txt"
                    mock_validator.export_to_lammps.return_value = "nep_lammps.txt"
                    
                    results = pipeline.run(
                        vasp_outcars=[str(outcar)],
                        type_list=['Li', 'S'],
                        preset="fast"
                    )
                    
                    assert 'train_xyz' in results
                    assert 'model_file' in results


# =============================================================================
# Standalone Test Functions
# =============================================================================

@pytest.mark.unit
def test_dataclass_nep_data_config():
    """Test NEPDataConfig dataclass."""
    from nep_training_pipeline import NEPDataConfig
    
    config = NEPDataConfig(
        energy_threshold=100.0,
        train_ratio=0.8,
        type_map=['Li', 'S', 'P']
    )
    
    assert config.energy_threshold == 100.0
    assert config.train_ratio == 0.8
    assert config.type_map == ['Li', 'S', 'P']


@pytest.mark.unit
def test_dataclass_nep_model_config():
    """Test NEPModelConfig dataclass."""
    from nep_training_pipeline import NEPModelConfig
    
    config = NEPModelConfig(
        type_list=['Li', 'S'],
        version=4,
        cutoff_radial=8.0,
        neuron=50
    )
    
    assert config.type_list == ['Li', 'S']
    assert config.version == 4
    assert config.cutoff_radial == 8.0
    assert config.neuron == 50


@pytest.mark.unit
def test_dataclass_nep_training_config():
    """Test NEPTrainingConfig dataclass."""
    from nep_training_pipeline import NEPTrainingConfig
    
    config = NEPTrainingConfig(
        gpumd_path="/opt/gpumd",
        use_gpu=True,
        gpu_id=1
    )
    
    assert config.gpumd_path == "/opt/gpumd"
    assert config.use_gpu is True
    assert config.gpu_id == 1