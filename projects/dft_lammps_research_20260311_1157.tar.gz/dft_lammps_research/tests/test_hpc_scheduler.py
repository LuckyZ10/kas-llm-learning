"""
HPC Scheduler Tests
===================

Tests for HPC job scheduling functionality:
- Slurm scheduler
- PBS/Torque scheduler
- LSF scheduler
- Local scheduler
- Workflow management

Run with: pytest tests/test_hpc_scheduler.py -v
"""

import os
import sys
import json
import pytest
import subprocess
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock, mock_open, call
from datetime import timedelta


# =============================================================================
# Test Class: Resource Request Tests
# =============================================================================

@pytest.mark.unit
@pytest.mark.hpc
class TestResourceRequest:
    """Test suite for resource request configuration."""
    
    def test_resource_request_initialization(self):
        """Test resource request initialization."""
        from hpc_scheduler import ResourceRequest
        
        resources = ResourceRequest(
            num_nodes=2,
            num_cores_per_node=32,
            num_gpus=4,
            memory_gb=128,
            walltime_hours=24.0,
            queue="gpu"
        )
        
        assert resources.num_nodes == 2
        assert resources.num_cores_per_node == 32
        assert resources.num_gpus == 4
        assert resources.memory_gb == 128
        assert resources.walltime_hours == 24.0
        assert resources.queue == "gpu"
    
    def test_resource_request_defaults(self):
        """Test resource request default values."""
        from hpc_scheduler import ResourceRequest
        
        resources = ResourceRequest()
        
        assert resources.num_nodes == 1
        assert resources.num_cores_per_node == 1
        assert resources.num_gpus == 0
        assert resources.walltime_hours == 24.0
    
    def test_to_slurm_basic(self):
        """Test conversion to Slurm format."""
        from hpc_scheduler import ResourceRequest
        
        resources = ResourceRequest(
            num_nodes=2,
            num_cores_per_node=16,
            walltime_hours=12.5
        )
        
        slurm_str = resources.to_slurm()
        
        assert "#SBATCH --nodes=2" in slurm_str
        assert "#SBATCH --ntasks-per-node=16" in slurm_str
        assert "#SBATCH --time=12:30:00" in slurm_str
    
    def test_to_slurm_with_gpu(self):
        """Test Slurm conversion with GPU resources."""
        from hpc_scheduler import ResourceRequest
        
        resources = ResourceRequest(
            num_nodes=1,
            num_cores_per_node=8,
            num_gpus=2,
            gpu_type="a100"
        )
        
        slurm_str = resources.to_slurm()
        
        assert "#SBATCH --gpus=2" in slurm_str
        assert "a100" in slurm_str or "gres=gpu" in slurm_str
    
    def test_to_slurm_with_memory(self):
        """Test Slurm conversion with memory specification."""
        from hpc_scheduler import ResourceRequest
        
        resources = ResourceRequest(memory_gb=64)
        slurm_str = resources.to_slurm()
        
        assert "#SBATCH --mem=65536" in slurm_str
    
    def test_to_slurm_exclusive(self):
        """Test Slurm conversion with exclusive flag."""
        from hpc_scheduler import ResourceRequest
        
        resources = ResourceRequest(exclusive=True)
        slurm_str = resources.to_slurm()
        
        assert "#SBATCH --exclusive" in slurm_str
    
    def test_to_pbs_basic(self):
        """Test conversion to PBS format."""
        from hpc_scheduler import ResourceRequest
        
        resources = ResourceRequest(
            num_nodes=2,
            num_cores_per_node=8,
            walltime_hours=6.0
        )
        
        pbs_str = resources.to_pbs()
        
        assert "#PBS -l nodes=2:ppn=8" in pbs_str
        assert "#PBS -l walltime=06:00:00" in pbs_str
    
    def test_to_pbs_with_gpu(self):
        """Test PBS conversion with GPU."""
        from hpc_scheduler import ResourceRequest
        
        resources = ResourceRequest(num_gpus=2)
        pbs_str = resources.to_pbs()
        
        assert "#PBS -l ngpus=2" in pbs_str
    
    def test_to_lsf_basic(self):
        """Test conversion to LSF format."""
        from hpc_scheduler import ResourceRequest
        
        resources = ResourceRequest(
            num_nodes=2,
            num_cores_per_node=16,
            walltime_hours=8.5
        )
        
        lsf_str = resources.to_lsf()
        
        assert "#BSUB -n 32" in lsf_str  # 2 * 16
        assert "#BSUB -W 8:30" in lsf_str
    
    def test_to_lsf_with_gpu(self):
        """Test LSF conversion with GPU."""
        from hpc_scheduler import ResourceRequest
        
        resources = ResourceRequest(num_gpus=4)
        lsf_str = resources.to_lsf()
        
        assert "#BSUB -gpu" in lsf_str
        assert "num=4" in lsf_str


# =============================================================================
# Test Class: Job Specification Tests
# =============================================================================

@pytest.mark.unit
@pytest.mark.hpc
class TestJobSpec:
    """Test suite for job specifications."""
    
    def test_job_spec_initialization(self, mock_working_dir):
        """Test job specification initialization."""
        from hpc_scheduler import JobSpec, ResourceRequest
        
        resources = ResourceRequest(num_nodes=1)
        spec = JobSpec(
            name="test_job",
            working_dir=mock_working_dir,
            commands=["echo 'hello'", "python script.py"],
            resources=resources,
            stdout_file="output.log",
            stderr_file="error.log"
        )
        
        assert spec.name == "test_job"
        assert spec.working_dir == mock_working_dir
        assert len(spec.commands) == 2
        assert spec.stdout_file == "output.log"
    
    def test_job_spec_with_dependencies(self, mock_working_dir):
        """Test job specification with dependencies."""
        from hpc_scheduler import JobSpec, ResourceRequest
        
        spec = JobSpec(
            name="dependent_job",
            working_dir=mock_working_dir,
            commands=["echo 'dependent'"],
            resources=ResourceRequest(),
            dependencies=["12345", "12346"],
            dependency_type="afterok"
        )
        
        assert spec.dependencies == ["12345", "12346"]
        assert spec.dependency_type == "afterok"
    
    def test_job_spec_with_array(self, mock_working_dir):
        """Test job specification with array range."""
        from hpc_scheduler import JobSpec, ResourceRequest
        
        spec = JobSpec(
            name="array_job",
            working_dir=mock_working_dir,
            commands=["echo $SLURM_ARRAY_TASK_ID"],
            resources=ResourceRequest(),
            array_range=(1, 100, 1)
        )
        
        assert spec.array_range == (1, 100, 1)


# =============================================================================
# Test Class: Local Scheduler Tests
# =============================================================================

@pytest.mark.unit
@pytest.mark.hpc
class TestLocalScheduler:
    """Test suite for local scheduler."""
    
    def test_local_scheduler_initialization(self):
        """Test local scheduler initialization."""
        from hpc_scheduler import LocalScheduler
        
        scheduler = LocalScheduler()
        
        assert scheduler._jobs == {}
        assert scheduler._job_counter == 0
    
    def test_local_scheduler_check_availability(self):
        """Test that local scheduler is always available."""
        from hpc_scheduler import LocalScheduler
        
        scheduler = LocalScheduler()
        
        assert scheduler._check_availability() is True
    
    def test_local_scheduler_submit(self, mock_job_spec):
        """Test submitting job to local scheduler."""
        from hpc_scheduler import LocalScheduler
        
        scheduler = LocalScheduler()
        
        with patch('subprocess.Popen') as mock_popen:
            mock_process = Mock()
            mock_process.poll.return_value = None
            mock_popen.return_value = mock_process
            
            job_id = scheduler.submit(mock_job_spec)
            
            assert job_id.startswith("local_")
            assert job_id in scheduler._jobs
    
    def test_local_scheduler_cancel(self, mock_job_spec):
        """Test cancelling job in local scheduler."""
        from hpc_scheduler import LocalScheduler
        
        scheduler = LocalScheduler()
        
        with patch('subprocess.Popen') as mock_popen:
            mock_process = Mock()
            mock_process.poll.return_value = None
            mock_popen.return_value = mock_process
            
            job_id = scheduler.submit(mock_job_spec)
            result = scheduler.cancel(job_id)
            
            assert result is True
            mock_process.terminate.assert_called_once()
    
    def test_local_scheduler_query_running(self, mock_job_spec):
        """Test querying running job."""
        from hpc_scheduler import LocalScheduler, JobStatus
        
        scheduler = LocalScheduler()
        
        with patch('subprocess.Popen') as mock_popen:
            mock_process = Mock()
            mock_process.poll.return_value = None
            mock_popen.return_value = mock_process
            
            job_id = scheduler.submit(mock_job_spec)
            jobs = scheduler.query(job_id)
            
            assert len(jobs) == 1
            assert jobs[0].status == JobStatus.RUNNING
    
    def test_local_scheduler_query_completed(self, mock_job_spec):
        """Test querying completed job."""
        from hpc_scheduler import LocalScheduler, JobStatus
        
        scheduler = LocalScheduler()
        
        with patch('subprocess.Popen') as mock_popen:
            mock_process = Mock()
            mock_process.poll.return_value = 0
            mock_popen.return_value = mock_process
            
            job_id = scheduler.submit(mock_job_spec)
            jobs = scheduler.query(job_id)
            
            assert len(jobs) == 1
            assert jobs[0].status == JobStatus.COMPLETED
            assert jobs[0].exit_code == 0
    
    def test_local_scheduler_query_failed(self, mock_job_spec):
        """Test querying failed job."""
        from hpc_scheduler import LocalScheduler, JobStatus
        
        scheduler = LocalScheduler()
        
        with patch('subprocess.Popen') as mock_popen:
            mock_process = Mock()
            mock_process.poll.return_value = 1
            mock_popen.return_value = mock_process
            
            job_id = scheduler.submit(mock_job_spec)
            jobs = scheduler.query(job_id)
            
            assert len(jobs) == 1
            assert jobs[0].status == JobStatus.FAILED
            assert jobs[0].exit_code == 1
    
    def test_local_scheduler_get_queues(self):
        """Test getting queue information."""
        from hpc_scheduler import LocalScheduler
        
        scheduler = LocalScheduler()
        queues = scheduler.get_queues()
        
        assert len(queues) >= 1
        assert queues[0]["name"] == "local"
        assert queues[0]["available"] is True
    
    def test_local_scheduler_estimate_wait_time(self):
        """Test wait time estimation (should be zero for local)."""
        from hpc_scheduler import LocalScheduler, ResourceRequest
        
        scheduler = LocalScheduler()
        resources = ResourceRequest()
        
        wait_time = scheduler.estimate_wait_time(resources)
        
        assert wait_time == timedelta(0)


# =============================================================================
# Test Class: Slurm Scheduler Tests
# =============================================================================

@pytest.mark.unit
@pytest.mark.hpc
class TestSlurmScheduler:
    """Test suite for Slurm scheduler."""
    
    def test_slurm_scheduler_initialization(self):
        """Test Slurm scheduler initialization."""
        from hpc_scheduler import SlurmScheduler
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(returncode=0, stdout="slurm 20.11.3")
            
            scheduler = SlurmScheduler()
            
            assert scheduler is not None
    
    def test_slurm_check_availability_success(self):
        """Test Slurm availability check (success)."""
        from hpc_scheduler import SlurmScheduler
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(returncode=0)
            
            scheduler = SlurmScheduler()
            available = scheduler._check_availability()
            
            assert available is True
    
    def test_slurm_check_availability_failure(self):
        """Test Slurm availability check (failure)."""
        from hpc_scheduler import SlurmScheduler
        
        with patch('subprocess.run') as mock_run:
            mock_run.side_effect = FileNotFoundError()
            
            scheduler = SlurmScheduler()
            available = scheduler._check_availability()
            
            assert available is False
    
    def test_slurm_generate_script(self, mock_job_spec):
        """Test Slurm script generation."""
        from hpc_scheduler import SlurmScheduler
        
        scheduler = SlurmScheduler()
        
        script = scheduler.generate_script(mock_job_spec)
        
        assert "#!/bin/bash" in script
        assert "#SBATCH --job-name=test_job" in script
        assert "echo 'Hello World'" in script
    
    def test_slurm_generate_script_with_dependencies(self, mock_job_spec):
        """Test Slurm script with dependencies."""
        from hpc_scheduler import SlurmScheduler, JobSpec, ResourceRequest
        
        scheduler = SlurmScheduler()
        
        spec = JobSpec(
            name="dependent_job",
            working_dir=mock_job_spec.working_dir,
            commands=["echo 'test'"],
            resources=ResourceRequest(),
            dependencies=["12345", "12346"],
            dependency_type="afterok"
        )
        
        script = scheduler.generate_script(spec)
        
        assert "#SBATCH --dependency=afterok:12345:12346" in script
    
    def test_slurm_generate_script_with_array(self, mock_job_spec):
        """Test Slurm script with array jobs."""
        from hpc_scheduler import SlurmScheduler, JobSpec, ResourceRequest
        
        scheduler = SlurmScheduler()
        
        spec = JobSpec(
            name="array_job",
            working_dir=mock_job_spec.working_dir,
            commands=["echo $SLURM_ARRAY_TASK_ID"],
            resources=ResourceRequest(),
            array_range=(1, 100, 2)
        )
        
        script = scheduler.generate_script(spec)
        
        assert "#SBATCH --array=1-100:2" in script
    
    def test_slurm_submit(self, mock_job_spec):
        """Test Slurm job submission."""
        from hpc_scheduler import SlurmScheduler
        
        scheduler = SlurmScheduler()
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(
                returncode=0,
                stdout="Submitted batch job 12345"
            )
            
            job_id = scheduler.submit(mock_job_spec)
            
            assert job_id == "12345"
    
    def test_slurm_submit_failure(self, mock_job_spec):
        """Test Slurm job submission failure."""
        from hpc_scheduler import SlurmScheduler
        
        scheduler = SlurmScheduler()
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(
                returncode=1,
                stderr="sbatch: error: Batch job submission failed"
            )
            
            with pytest.raises(RuntimeError, match="Failed to submit job"):
                scheduler.submit(mock_job_spec)
    
    def test_slurm_cancel(self):
        """Test Slurm job cancellation."""
        from hpc_scheduler import SlurmScheduler
        
        scheduler = SlurmScheduler()
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(returncode=0)
            
            result = scheduler.cancel("12345")
            
            assert result is True
            mock_run.assert_called_with(
                ["scancel", "12345"],
                capture_output=True,
                text=True
            )
    
    def test_slurm_query_running(self):
        """Test querying running Slurm job."""
        from hpc_scheduler import SlurmScheduler, JobStatus
        
        scheduler = SlurmScheduler()
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(
                returncode=0,
                stdout="12345|test_job|RUNNING|01:30:00|00:30:00|1|None"
            )
            
            jobs = scheduler.query("12345")
            
            assert len(jobs) == 1
            assert jobs[0].job_id == "12345"
            assert jobs[0].status == JobStatus.RUNNING
    
    def test_slurm_query_pending(self):
        """Test querying pending Slurm job."""
        from hpc_scheduler import SlurmScheduler, JobStatus
        
        scheduler = SlurmScheduler()
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(
                returncode=0,
                stdout="12346|test_job|PENDING|00:00:00|NOT_SET|1|Resources"
            )
            
            jobs = scheduler.query("12346")
            
            assert len(jobs) == 1
            assert jobs[0].status == JobStatus.PENDING
    
    def test_slurm_query_completed(self):
        """Test querying completed Slurm job."""
        from hpc_scheduler import SlurmScheduler, JobStatus
        
        scheduler = SlurmScheduler()
        
        with patch('subprocess.run') as mock_run:
            # First call to squeue fails (job not in queue)
            # Second call to sacct succeeds
            mock_run.side_effect = [
                Mock(returncode=1, stdout="", stderr=""),
                Mock(
                    returncode=0,
                    stdout="12345|test_job|COMPLETED|0:0|02:30:00"
                )
            ]
            
            jobs = scheduler.query("12345")
            
            assert len(jobs) == 1
            assert jobs[0].status == JobStatus.COMPLETED
    
    def test_slurm_get_queues(self):
        """Test getting Slurm queue information."""
        from hpc_scheduler import SlurmScheduler
        
        scheduler = SlurmScheduler()
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(
                returncode=0,
                stdout="normal*|up|24:00:00|100|idle|node[01-100]\ngpu|up|12:00:00|20|mix|gpu[01-20]"
            )
            
            queues = scheduler.get_queues()
            
            assert len(queues) == 2
            assert queues[0]["name"] == "normal"
            assert queues[0]["is_default"] is True
            assert queues[1]["name"] == "gpu"
    
    def test_slurm_estimate_wait_time(self):
        """Test Slurm wait time estimation."""
        from hpc_scheduler import SlurmScheduler, ResourceRequest
        
        scheduler = SlurmScheduler()
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(
                returncode=0,
                stdout="12345|PENDING\n12346|PENDING\n12347|PENDING"
            )
            
            resources = ResourceRequest()
            wait_time = scheduler.estimate_wait_time(resources)
            
            assert wait_time is not None
            assert wait_time > timedelta(0)
    
    def test_slurm_wait_for_job(self):
        """Test waiting for Slurm job completion."""
        from hpc_scheduler import SlurmScheduler, JobStatus
        
        scheduler = SlurmScheduler()
        
        with patch.object(scheduler, 'query') as mock_query:
            # First call: running, Second call: completed
            mock_query.side_effect = [
                [Mock(status=JobStatus.RUNNING)],
                [Mock(status=JobStatus.COMPLETED)]
            ]
            
            with patch('time.sleep', return_value=None):
                status = scheduler.wait_for_job("12345", poll_interval=0)
                
                assert status == JobStatus.COMPLETED


# =============================================================================
# Test Class: PBS Scheduler Tests
# =============================================================================

@pytest.mark.unit
@pytest.mark.hpc
class TestPBSScheduler:
    """Test suite for PBS scheduler."""
    
    def test_pbs_scheduler_initialization(self):
        """Test PBS scheduler initialization."""
        from hpc_scheduler import PBSScheduler
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(returncode=0, stderr="version: 6.1.2")
            
            scheduler = PBSScheduler()
            
            assert scheduler is not None
    
    def test_pbs_generate_script(self, mock_job_spec):
        """Test PBS script generation."""
        from hpc_scheduler import PBSScheduler
        
        scheduler = PBSScheduler()
        
        script = scheduler.generate_script(mock_job_spec)
        
        assert "#!/bin/bash" in script
        assert "#PBS -N test_job" in script
        assert "echo 'Hello World'" in script
    
    def test_pbs_submit(self, mock_job_spec):
        """Test PBS job submission."""
        from hpc_scheduler import PBSScheduler
        
        scheduler = PBSScheduler()
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(
                returncode=0,
                stdout="12345.server"
            )
            
            job_id = scheduler.submit(mock_job_spec)
            
            assert job_id == "12345.server"
    
    def test_pbs_cancel(self):
        """Test PBS job cancellation."""
        from hpc_scheduler import PBSScheduler
        
        scheduler = PBSScheduler()
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(returncode=0)
            
            result = scheduler.cancel("12345")
            
            assert result is True
    
    def test_pbs_query(self):
        """Test querying PBS job."""
        from hpc_scheduler import PBSScheduler, JobStatus
        
        scheduler = PBSScheduler()
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(
                returncode=0,
                stdout="Job Id: 12345.server\n    Job_Name = test_job\n    job_state = R\n"
            )
            
            jobs = scheduler.query("12345")
            
            assert len(jobs) == 1
            assert jobs[0].job_id == "12345.server"
            assert jobs[0].status == JobStatus.RUNNING


# =============================================================================
# Test Class: LSF Scheduler Tests
# =============================================================================

@pytest.mark.unit
@pytest.mark.hpc
class TestLSFScheduler:
    """Test suite for LSF scheduler."""
    
    def test_lsf_scheduler_initialization(self):
        """Test LSF scheduler initialization."""
        from hpc_scheduler import LSFScheduler
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(returncode=0, stderr="Platform LSF")
            
            scheduler = LSFScheduler()
            
            assert scheduler is not None
    
    def test_lsf_generate_script(self, mock_job_spec):
        """Test LSF script generation."""
        from hpc_scheduler import LSFScheduler
        
        scheduler = LSFScheduler()
        
        script = scheduler.generate_script(mock_job_spec)
        
        assert "#!/bin/bash" in script
        assert "#BSUB -J test_job" in script
        assert "echo 'Hello World'" in script
    
    def test_lsf_submit(self, mock_job_spec):
        """Test LSF job submission."""
        from hpc_scheduler import LSFScheduler
        
        scheduler = LSFScheduler()
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(
                returncode=0,
                stdout="Job <12345> is submitted to queue <normal>."
            )
            
            job_id = scheduler.submit(mock_job_spec)
            
            assert job_id == "12345"
    
    def test_lsf_cancel(self):
        """Test LSF job cancellation."""
        from hpc_scheduler import LSFScheduler
        
        scheduler = LSFScheduler()
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(returncode=0)
            
            result = scheduler.cancel("12345")
            
            assert result is True
    
    def test_lsf_query(self):
        """Test querying LSF job."""
        from hpc_scheduler import LSFScheduler, JobStatus
        
        scheduler = LSFScheduler()
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(
                returncode=0,
                stdout="12345    test_job             RUN     normal          01:30"
            )
            
            jobs = scheduler.query("12345")
            
            assert len(jobs) == 1
            assert jobs[0].job_id == "12345"
            assert jobs[0].status == JobStatus.RUNNING
    
    def test_lsf_get_queues(self):
        """Test getting LSF queue information."""
        from hpc_scheduler import LSFScheduler
        
        scheduler = LSFScheduler()
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(
                returncode=0,
                stdout="normal   50       Open    1000  -  10  5  0"
            )
            
            queues = scheduler.get_queues()
            
            assert len(queues) >= 1
            assert queues[0]["name"] == "normal"


# =============================================================================
# Test Class: Workflow Manager Tests
# =============================================================================

@pytest.mark.unit
@pytest.mark.hpc
class TestWorkflowManager:
    """Test suite for workflow management."""
    
    def test_workflow_manager_initialization(self):
        """Test workflow manager initialization."""
        from hpc_scheduler import WorkflowManager, LocalScheduler
        
        scheduler = LocalScheduler()
        manager = WorkflowManager(scheduler)
        
        assert manager.scheduler == scheduler
        assert manager._jobs == {}
    
    def test_workflow_manager_default_scheduler(self):
        """Test workflow manager creates default scheduler."""
        from hpc_scheduler import WorkflowManager
        
        with patch('hpc_scheduler.detect_scheduler') as mock_detect:
            mock_detect.return_value = Mock()
            
            manager = WorkflowManager()
            
            assert manager.scheduler is not None
    
    def test_submit_task(self, mock_job_spec):
        """Test submitting task through workflow manager."""
        from hpc_scheduler import WorkflowManager, LocalScheduler
        
        scheduler = LocalScheduler()
        manager = WorkflowManager(scheduler)
        
        with patch.object(scheduler, 'submit') as mock_submit:
            mock_submit.return_value = "local_1"
            
            job_id = manager.submit_task("task1", mock_job_spec)
            
            assert job_id == "local_1"
            assert manager._jobs["task1"] == "local_1"
    
    def test_submit_task_with_dependencies(self, mock_job_spec):
        """Test submitting task with dependencies."""
        from hpc_scheduler import WorkflowManager, LocalScheduler, JobSpec, ResourceRequest
        
        scheduler = LocalScheduler()
        manager = WorkflowManager(scheduler)
        
        # Submit first task
        with patch.object(scheduler, 'submit') as mock_submit:
            mock_submit.return_value = "local_1"
            manager.submit_task("task1", mock_job_spec)
        
        # Submit second task depending on first
        spec2 = JobSpec(
            name="task2",
            working_dir=mock_job_spec.working_dir,
            commands=["echo 'task2'"],
            resources=ResourceRequest()
        )
        
        with patch.object(scheduler, 'submit') as mock_submit:
            mock_submit.return_value = "local_2"
            
            job_id = manager.submit_task("task2", spec2, depends_on=["task1"])
            
            assert job_id == "local_2"
            assert "local_1" in spec2.dependencies
    
    def test_get_status(self, mock_job_spec):
        """Test getting workflow status."""
        from hpc_scheduler import WorkflowManager, LocalScheduler, JobStatus
        
        scheduler = LocalScheduler()
        manager = WorkflowManager(scheduler)
        
        with patch.object(scheduler, 'submit') as mock_submit:
            mock_submit.return_value = "local_1"
            manager.submit_task("task1", mock_job_spec)
        
        with patch.object(scheduler, 'query') as mock_query:
            mock_query.return_value = [Mock(status=JobStatus.RUNNING)]
            
            status = manager.get_status()
            
            assert "task1" in status
    
    def test_wait_for_all(self, mock_job_spec):
        """Test waiting for all tasks."""
        from hpc_scheduler import WorkflowManager, LocalScheduler, JobStatus
        
        scheduler = LocalScheduler()
        manager = WorkflowManager(scheduler)
        
        with patch.object(scheduler, 'submit') as mock_submit:
            mock_submit.return_value = "local_1"
            manager.submit_task("task1", mock_job_spec)
        
        with patch.object(scheduler, 'wait_for_job') as mock_wait:
            mock_wait.return_value = JobStatus.COMPLETED
            
            results = manager.wait_for_all(timeout=5.0)
            
            assert "task1" in results
            assert results["task1"] == JobStatus.COMPLETED


# =============================================================================
# Test Class: Scheduler Detection Tests
# =============================================================================

@pytest.mark.unit
@pytest.mark.hpc
class TestSchedulerDetection:
    """Test suite for scheduler auto-detection."""
    
    def test_detect_slurm(self):
        """Test Slurm detection."""
        from hpc_scheduler import detect_scheduler, SchedulerType
        
        with patch('subprocess.run') as mock_run:
            mock_run.return_value = Mock(returncode=0)
            
            sched_type = detect_scheduler()
            
            assert sched_type == SchedulerType.SLURM
    
    def test_detect_pbs(self):
        """Test PBS detection when Slurm not available."""
        from hpc_scheduler import detect_scheduler, SchedulerType
        
        def side_effect(*args, **kwargs):
            if args[0][0] == "sbatch":
                raise FileNotFoundError()
            elif args[0][0] == "qsub":
                return Mock(returncode=0)
            return Mock(returncode=0)
        
        with patch('subprocess.run', side_effect=side_effect):
            sched_type = detect_scheduler()
            
            assert sched_type == SchedulerType.PBS
    
    def test_detect_local(self):
        """Test fallback to local scheduler."""
        from hpc_scheduler import detect_scheduler, SchedulerType
        
        with patch('subprocess.run') as mock_run:
            mock_run.side_effect = FileNotFoundError()
            
            sched_type = detect_scheduler()
            
            assert sched_type == SchedulerType.LOCAL


# =============================================================================
# Test Class: Job Status Tests
# =============================================================================

@pytest.mark.unit
@pytest.mark.hpc
class TestJobStatus:
    """Test suite for job status enum."""
    
    def test_job_status_values(self):
        """Test job status enum values."""
        from hpc_scheduler import JobStatus
        
        assert JobStatus.PENDING.value == "pending"
        assert JobStatus.RUNNING.value == "running"
        assert JobStatus.COMPLETED.value == "completed"
        assert JobStatus.FAILED.value == "failed"
        assert JobStatus.CANCELLED.value == "cancelled"
        assert JobStatus.TIMEOUT.value == "timeout"
        assert JobStatus.UNKNOWN.value == "unknown"
    
    def test_job_status_is_terminal(self):
        """Test terminal status detection."""
        from hpc_scheduler import JobStatus
        
        terminal_statuses = [
            JobStatus.COMPLETED,
            JobStatus.FAILED,
            JobStatus.CANCELLED,
            JobStatus.TIMEOUT
        ]
        
        non_terminal_statuses = [
            JobStatus.PENDING,
            JobStatus.RUNNING,
            JobStatus.UNKNOWN
        ]
        
        for status in terminal_statuses:
            assert status in terminal_statuses
        
        for status in non_terminal_statuses:
            assert status in non_terminal_statuses


# =============================================================================
# Standalone Test Functions
# =============================================================================

@pytest.mark.unit
@pytest.mark.hpc
def test_create_scheduler_factory_function():
    """Test scheduler factory function."""
    from hpc_scheduler import create_scheduler, SchedulerType
    
    with patch('hpc_scheduler.detect_scheduler') as mock_detect:
        mock_detect.return_value = SchedulerType.LOCAL
        
        scheduler = create_scheduler()
        
        assert scheduler is not None


@pytest.mark.unit
@pytest.mark.hpc
def test_create_scheduler_explicit_type():
    """Test creating scheduler with explicit type."""
    from hpc_scheduler import create_scheduler
    
    scheduler = create_scheduler("local")
    
    assert scheduler is not None


@pytest.mark.unit
@pytest.mark.hpc
def test_submit_dft_calculation_helper():
    """Test DFT calculation submission helper."""
    from hpc_scheduler import submit_dft_calculation
    
    with patch('hpc_scheduler.create_scheduler') as mock_create:
        mock_scheduler = Mock()
        mock_scheduler.submit.return_value = "12345"
        mock_create.return_value = mock_scheduler
        
        job_id = submit_dft_calculation(
            working_dir="/tmp/test",
            calc_type="vasp"
        )
        
        assert job_id == "12345"
        mock_scheduler.submit.assert_called_once()


@pytest.mark.unit
@pytest.mark.hpc
def test_submit_gpu_job_helper():
    """Test GPU job submission helper."""
    from hpc_scheduler import submit_gpu_job
    
    with patch('hpc_scheduler.create_scheduler') as mock_create:
        mock_scheduler = Mock()
        mock_scheduler.submit.return_value = "12346"
        mock_create.return_value = mock_scheduler
        
        job_id = submit_gpu_job(
            working_dir="/tmp/test",
            command="python train.py",
            num_gpus=2,
            gpu_type="a100"
        )
        
        assert job_id == "12346"
        mock_scheduler.submit.assert_called_once()