"""
DFT+LAMMPS Integration Package
==============================

A comprehensive Python package for integrating DFT (Density Functional Theory) 
calculations with classical molecular dynamics simulations using LAMMPS, 
enhanced with machine learning potentials and topological materials analysis.

Main Modules
------------
- core: Core modules for DFT, ML potentials, and MD simulations
- ai: AI/ML modules for materials discovery (generative models, property prediction, Bayesian optimization)
- hpc: High-performance computing job scheduling and optimization
- topology: Topological materials calculations (Z2 invariants, Berry phases, surface states)
- weyl: Weyl semimetal analysis (Weyl points, Fermi arcs, chiral anomaly)
- applications: Application cases (catalysts, batteries, topological materials, AI discovery)
- utils: Utility functions and helpers

Topological Materials Features
------------------------------
- Z2Pack interface for topological invariant calculations
- WannierTools interface for surface states and Weyl points
- Berry phase and anomalous Hall conductivity calculations
- Weyl point location and classification
- Fermi arc surface state analysis

Quick Start
-----------
>>> from dftlammps import IntegratedWorkflow
>>> workflow = IntegratedWorkflow()
>>> workflow.run()

>>> # Topological insulator analysis
>>> from dftlammps.topology import Z2VASPInterface, Z2PackConfig
>>> config = Z2PackConfig(surface="kz-surface")
>>> interface = Z2VASPInterface("./Bi2Se3", config)
>>> result = interface.calculate_z2_invariant()

>>> # Weyl semimetal analysis
>>> from dftlammps.weyl import locate_weyl_points
>>> weyl_points = locate_weyl_points("./TaAs")

Version
-------
1.0.0

Author
------
DFT+LAMMPS Integration Team

License
-------
MIT License
"""

__version__ = "1.0.0"
__author__ = "DFT+LAMMPS Integration Team"
__email__ = "dftlammps@example.com"
__license__ = "MIT"

# Core imports
from .core.dft_bridge import (
    VASPParserConfig,
    ForceFieldConfig,
    LAMMPSInputConfig,
    DFTToLAMMPSBridge,
    VASPDataExtractor,
    ForceFieldFitter,
    LAMMPSInputGenerator,
)

from .core.ml_potential import (
    NEPDataConfig,
    NEPModelConfig,
    NEPTrainingPipeline,
)

from .core.md_simulation import (
    MDConfig,
    MDSimulationRunner,
    MDTrajectoryAnalyzer,
)

from .core.workflow import (
    WorkflowStage,
    MaterialsProjectConfig,
    DFTStageConfig,
    MLPotentialConfig,
    MDStageConfig,
    AnalysisConfig,
    IntegratedWorkflowConfig,
    IntegratedMaterialsWorkflow,
)

# HPC imports
from .hpc.scheduler import (
    SchedulerType,
    JobStatus,
    ResourceRequest,
    JobSpec,
    JobInfo,
    HPCScheduler,
    SlurmScheduler,
    PBSScheduler,
    LSFScheduler,
    LocalScheduler,
    ParallelOptimizer,
)

# Application imports
from .applications.screening import (
    BatteryScreeningConfig,
    FeatureEngineer,
    PerformancePredictor,
    BatteryScreeningPipeline,
)

# Utils imports
from .utils.checkpoint import CheckpointManager
from .utils.monitoring import MonitoringDashboard

# Advanced DFT imports
try:
    from .dft_advanced import (
        # Optical properties
        OpticalPropertyWorkflow,
        VASPOpticalCalculator,
        QEOpticalCalculator,
        DielectricFunction,
        OpticalSpectrum,
        ExcitonPeak,
        EllipsometryParams,
        VASPOpticalConfig,
        QEOpticalConfig,
        
        # Magnetic properties
        MagneticPropertyWorkflow,
        VASPMagneticCalculator,
        QEMagneticCalculator,
        MagneticState,
        MagneticAnisotropy,
        ExchangeCoupling,
        CurieTemperature,
        SpinConfiguration,
        VASPMagneticConfig,
        QEMagneticConfig,
        SpinConfigurationGenerator,
        
        # Defect calculations
        DefectCalculationWorkflow,
        DefectStructureGenerator,
        FormationEnergyCalculator,
        FiniteSizeCorrectionCalculator,
        NEBDiffusionCalculator,
        DefectSpec,
        FormationEnergy,
        TransitionLevel,
        DefectConfig,
        DefectType,
        
        # Nonlinear response
        NonlinearResponseWorkflow,
        ElasticConstantsCalculator,
        PiezoelectricCalculator,
        SHGCalculator,
        ElasticTensor,
        PiezoelectricTensor,
        SHGTensor,
    )
    HAS_ADVANCED_DFT = True
except ImportError as e:
    HAS_ADVANCED_DFT = False
    import warnings
    warnings.warn(f"Advanced DFT module not available: {e}")

# Solvation imports
try:
    from .solvation import (
        # VASPsol
        VASPsolWorkflow,
        VASPsolCalculator,
        ElectrochemicalInterface,
        VASPsolConfig,
        SolvationResults,
        ElectrochemicalConfig,
        
        # CP2K solvation
        CP2KSolvationWorkflow,
        CP2KElectrochemicalInterface,
        ExplicitSolventSetup,
        CP2KSolvationConfig,
        CP2KElectrolyteConfig,
        CP2KInputGenerator,
    )
    HAS_SOLVATION = True
except ImportError as e:
    HAS_SOLVATION = False
    import warnings
    warnings.warn(f"Solvation module not available: {e}")

# Advanced DFT Workflow integration
try:
    from .advanced_dft_workflow import (
        AdvancedDFTWorkflow,
        AdvancedDFTConfig,
        CalculationType,
        CalculationTypeAnalyzer,
        AutoParameterSelector,
    )
    HAS_ADVANCED_DFT_WORKFLOW = True
except ImportError as e:
    HAS_ADVANCED_DFT_WORKFLOW = False
    import warnings
    warnings.warn(f"Advanced DFT workflow not available: {e}")

# Multiscale imports
from .multiscale import (
    # Phase Field
    PhaseFieldConfig,
    DendriteConfig,
    SpinodalConfig,
    PhaseFieldSolver,
    DendriteGrowthSolver,
    SpinodalDecompositionSolver,
    MDtoPhaseFieldExtractor,
    PRISMSPFInterface,
    MOOSEInterface,
    PhaseFieldWorkflow,
    
    # Continuum
    ElasticProperties,
    ThermalProperties,
    MaterialModel,
    FEMConfig,
    MechanicsConfig,
    ThermalConfig,
    FEMMesh,
    ThermalSolver,
    MechanicsSolver,
    CoupledThermalMechanicsSolver,
    ContinuumWorkflow,
    
    # Parameter Passing
    ElasticConstants,
    TransportProperties,
    InterfaceProperties,
    PhaseFieldParameters,
    MultiScaleParameters,
    DFTParameterExtractor,
    MDParameterExtractor,
    ParameterConverter,
    ParameterValidator,
    ParameterPassingWorkflow,
)

# Advanced ML Potentials imports
try:
    from .advanced_potentials import (
        # Enums
        MLPotentialType,
        MLPotentialCapability,
        
        # Configs and Results
        UnifiedMLPotentialConfig,
        MLPredictionResult,
        MLPotentialInfo,
        MACEConfig,
        MACEMDConfig,
        CHGNetConfig,
        OrbConfig,
        OrbMDConfig,
        
        # Unified Interface
        UnifiedMLPotentialCalculator,
        UnifiedMLPotentialWorkflow,
        MLPotentialSelector,
        load_ml_potential,
        get_default_potential,
        
        # MACE
        MACECalculator,
        MACEWorkflow,
        MACEDatasetPreparer,
        MACEActiveLearning,
        
        # CHGNet
        CHGNetASECalculator,
        CHGNetWorkflow,
        CHGNetPrediction,
        MagneticProperties,
        
        # Orb
        OrbASECalculator,
        OrbWorkflow,
        OrbBatchPredictor,
        OrbBenchmarkResult,
        
        # Database
        ML_POTENTIAL_DATABASE,
    )
    HAS_ADVANCED_POTENTIALS = True
except ImportError as e:
    HAS_ADVANCED_POTENTIALS = False
    import warnings
    warnings.warn(f"Advanced potentials module not available: {e}")

# AI imports (optional - only if dependencies available)
try:
    from .ai import (
        # Generative Models
        StructureGenerator,
        CrystalStructure,
        GenerativeModelConfig,
        CDVAE,
        DiffCSP,
        MatterGen,
        load_pretrained_model,
        generate_structures_for_screening,
        
        # Property Predictors
        PropertyPredictor,
        PropertyPredictorConfig,
        MaterialGraph,
        CGCNN,
        MegNet,
        ALIGNN,
        TransformerModel,
        PretrainedModelLoader,
        load_pretrained_predictor,
        AtomFeatureEncoder,
        
        # Bayesian Optimization
        BayesianOptimizer,
        BayesianOptimizerConfig,
        OptimizationResult,
        GaussianProcessSurrogate,
        ExpectedImprovement,
        UpperConfidenceBound,
        optimize_materials,
        batch_bayesian_optimization,
        
        # Active Discovery
        ActiveDiscovery,
        ActiveDiscoveryConfig,
        ActiveDiscoveryResult,
        DiscoveryIteration,
        SamplingStrategy,
        UncertaintyEstimator,
        EnsembleUncertainty,
        MCDropoutUncertainty,
        QueryByCommittee,
        DiversitySampler,
        ActiveDiscoveryPipeline,
        run_active_discovery_for_battery_materials,
        run_active_discovery_for_catalysts,
        integrate_with_high_throughput_screening,
    )
    HAS_AI = True
except ImportError as e:
    HAS_AI = False
    import warnings
    warnings.warn(f"AI module not available: {e}")

__all__ = [
    # Version
    "__version__",
    "__author__",
    "__email__",
    
    # Core - DFT Bridge
    "VASPParserConfig",
    "ForceFieldConfig",
    "LAMMPSInputConfig",
    "DFTToLAMMPSBridge",
    "VASPDataExtractor",
    "ForceFieldFitter",
    "LAMMPSInputGenerator",
    
    # Core - ML Potential
    "NEPDataConfig",
    "NEPModelConfig",
    "NEPTrainingPipeline",
    
    # Core - MD Simulation
    "MDConfig",
    "MDSimulationRunner",
    "MDTrajectoryAnalyzer",
    
    # Core - Workflow
    "WorkflowStage",
    "MaterialsProjectConfig",
    "DFTStageConfig",
    "MLPotentialConfig",
    "MDStageConfig",
    "AnalysisConfig",
    "IntegratedWorkflowConfig",
    "IntegratedMaterialsWorkflow",
    
    # HPC
    "SchedulerType",
    "JobStatus",
    "ResourceRequest",
    "JobSpec",
    "JobInfo",
    "HPCScheduler",
    "SlurmScheduler",
    "PBSScheduler",
    "LSFScheduler",
    "LocalScheduler",
    "ParallelOptimizer",
    
    # Applications
    "BatteryScreeningConfig",
    "FeatureEngineer",
    "PerformancePredictor",
    "BatteryScreeningPipeline",
    
    # Utils
    "CheckpointManager",
    "MonitoringDashboard",
    
    # Multiscale - Phase Field
    "PhaseFieldConfig",
    "DendriteConfig",
    "SpinodalConfig",
    "PhaseFieldSolver",
    "DendriteGrowthSolver",
    "SpinodalDecompositionSolver",
    "MDtoPhaseFieldExtractor",
    "PRISMSPFInterface",
    "MOOSEInterface",
    "PhaseFieldWorkflow",
    
    # Multiscale - Continuum
    "ElasticProperties",
    "ThermalProperties",
    "MaterialModel",
    "FEMConfig",
    "MechanicsConfig",
    "ThermalConfig",
    "FEMMesh",
    "ThermalSolver",
    "MechanicsSolver",
    "CoupledThermalMechanicsSolver",
    "ContinuumWorkflow",
    
    # Multiscale - Parameter Passing
    "ElasticConstants",
    "TransportProperties",
    "InterfaceProperties",
    "PhaseFieldParameters",
    "MultiScaleParameters",
    "DFTParameterExtractor",
    "MDParameterExtractor",
    "ParameterConverter",
    "ParameterValidator",
    "ParameterPassingWorkflow",
]

# Add Advanced Potentials exports if available
if HAS_ADVANCED_POTENTIALS:
    __all__.extend([
        # Enums
        "MLPotentialType",
        "MLPotentialCapability",
        
        # Configs
        "UnifiedMLPotentialConfig",
        "MLPredictionResult",
        "MLPotentialInfo",
        "MACEConfig",
        "MACEMDConfig",
        "CHGNetConfig",
        "OrbConfig",
        "OrbMDConfig",
        
        # Unified Interface
        "UnifiedMLPotentialCalculator",
        "UnifiedMLPotentialWorkflow",
        "MLPotentialSelector",
        "load_ml_potential",
        "get_default_potential",
        
        # MACE
        "MACECalculator",
        "MACEWorkflow",
        "MACEDatasetPreparer",
        "MACEActiveLearning",
        
        # CHGNet
        "CHGNetASECalculator",
        "CHGNetWorkflow",
        "CHGNetPrediction",
        "MagneticProperties",
        
        # Orb
        "OrbASECalculator",
        "OrbWorkflow",
        "OrbBatchPredictor",
        "OrbBenchmarkResult",
        
        # Database
        "ML_POTENTIAL_DATABASE",
    ])

# Add AI exports if available
if HAS_AI:
    __all__.extend([
        # Generative Models
        "StructureGenerator",
        "CrystalStructure",
        "GenerativeModelConfig",
        "CDVAE",
        "DiffCSP",
        "MatterGen",
        "load_pretrained_model",
        "generate_structures_for_screening",
        
        # Property Predictors
        "PropertyPredictor",
        "PropertyPredictorConfig",
        "MaterialGraph",
        "CGCNN",
        "MegNet",
        "ALIGNN",
        "TransformerModel",
        "PretrainedModelLoader",
        "load_pretrained_predictor",
        "AtomFeatureEncoder",
        
        # Bayesian Optimization
        "BayesianOptimizer",
        "BayesianOptimizerConfig",
        "OptimizationResult",
        "GaussianProcessSurrogate",
        "ExpectedImprovement",
        "UpperConfidenceBound",
        "optimize_materials",
        "batch_bayesian_optimization",
        
        # Active Discovery
        "ActiveDiscovery",
        "ActiveDiscoveryConfig",
        "ActiveDiscoveryResult",
        "DiscoveryIteration",
        "SamplingStrategy",
        "UncertaintyEstimator",
        "EnsembleUncertainty",
        "MCDropoutUncertainty",
        "QueryByCommittee",
        "DiversitySampler",
        "ActiveDiscoveryPipeline",
        "run_active_discovery_for_battery_materials",
        "run_active_discovery_for_catalysts",
        "integrate_with_high_throughput_screening",
    ])

# Optional: Check dependencies
def check_dependencies():
    """Check if required dependencies are installed."""
    import importlib
    
    required = ['numpy', 'pandas', 'ase', 'pymatgen']
    optional = ['dpdata', 'dscribe', 'matminer', 'mp_api']
    
    missing_required = []
    missing_optional = []
    
    for pkg in required:
        try:
            importlib.import_module(pkg)
        except ImportError:
            missing_required.append(pkg)
    
    for pkg in optional:
        try:
            importlib.import_module(pkg)
        except ImportError:
            missing_optional.append(pkg)
    
    if missing_required:
        raise ImportError(
            f"Missing required dependencies: {', '.join(missing_required)}. "
            f"Install with: pip install {' '.join(missing_required)}"
        )
    
    if missing_optional:
        import warnings
        warnings.warn(
            f"Optional dependencies not installed: {', '.join(missing_optional)}. "
            f"Some features may be unavailable."
        )

# Advanced MD imports (optional)
try:
    from .md_advanced import (
        # Enhanced Sampling
        UmbrellaSamplingConfig,
        MetadynamicsConfig,
        REMDConfig,
        TADConfig,
        CollectiveVariable,
        DistanceCV,
        AngleCV,
        DihedralCV,
        CoordinationNumberCV,
        UmbrellaSampling,
        Metadynamics,
        REMD,
        TemperatureAcceleratedDynamics,
        estimate_free_energy_barrier,
        compute_error_pmf,
        
        # Free Energy
        FEPConfig,
        TIConfig,
        BARConfig,
        WHAMConfig,
        FreeEnergyPerturbation,
        ThermodynamicIntegration,
        BennettAcceptanceRatio,
        WHAM,
        MBAR,
        FreeEnergyAnalyzer,
        compute_solvation_free_energy,
        compute_binding_free_energy,
        
        # Rare Events
        NEBConfig,
        StringMethodConfig,
        DimerConfig,
        TSTConfig,
        NEB,
        StringMethod,
        DimerMethod,
        TransitionStateTheory,
        find_mep_from_ts,
        compute_activation_entropy,
        
        # Reaction Analysis
        ReactionPathSearchConfig,
        ReactionCoordinateConfig,
        RateConstantConfig,
        KMCConfig,
        ReactionPathSearcher,
        ReactionCoordinate,
        RateConstantCalculator,
        KMCPreprocessor,
        ReactionNetwork,
    )
    HAS_ADVANCED_MD = True
except ImportError as e:
    HAS_ADVANCED_MD = False
    import warnings
    warnings.warn(f"Advanced MD module not available: {e}")

# Advanced MD Analysis imports (optional)
try:
    from .md_analysis_advanced import (
        DynamicHeterogeneityConfig,
        DynamicHeterogeneityAnalyzer,
        StructuralAnalysisConfig,
        RingStatistics,
        VoronoiAnalysis,
        BondOrientationalOrder,
        CommonNeighborAnalysis,
        StructuralAnalyzer,
        CorrelationConfig,
        TimeCorrelationAnalyzer,
        VelocityAutocorrelation,
        StressAutocorrelation,
        DipoleAutocorrelation,
        IntermediateScattering,
        CorrelationAnalysisSuite,
    )
    HAS_ADVANCED_MD_ANALYSIS = True
except ImportError as e:
    HAS_ADVANCED_MD_ANALYSIS = False
    import warnings
    warnings.warn(f"Advanced MD analysis module not available: {e}")

# MLIP Training imports (optional)
try:
    from .mlip_training import (
        MLIPType,
        UnifiedTrainingConfig,
        PredictionResult,
        BaseMLIP,
        UnifiedMLIPTrainer,
        UnifiedMLIPCalculator,
        quick_train,
        load_model,
    )
    from .mlip_training.mace_training import (
        MACEDataConfig,
        MACEArchitectureConfig,
        MACETrainingConfig,
        MACERunConfig,
        MACEDatasetPreparer,
        MACETrainer,
        MACEEvaluator,
    )
    from .mlip_training.chgnet_training import (
        CHGNetDataConfig,
        CHGNetArchitectureConfig,
        CHGNetTrainingConfig,
        CHGNetRunConfig,
        CHGNetDatasetPreparer,
        CHGNetTrainer,
        CHGNetEvaluator,
    )
    from .mlip_training.orb_training import (
        OrbDataConfig,
        OrbArchitectureConfig,
        OrbTrainingConfig,
        OrbRunConfig,
        OrbDatasetPreparer,
        OrbTrainer,
        OrbEvaluator,
    )
    HAS_MLIP_TRAINING = True
except ImportError as e:
    HAS_MLIP_TRAINING = False
    import warnings
    warnings.warn(f"MLIP training module not available: {e}")

# Application cases imports (optional)
try:
    from .applications.case_ion_migration import (
        IonMigrationConfig,
        IonMigrationNEB,
        MigrationPathAnalyzer,
    )
    from .applications.case_phase_transition import (
        PhaseTransitionConfig,
        PhaseTransitionAnalyzer,
    )
    from .applications.case_catalytic_mechanism import (
        CatalyticReactionConfig,
        CatalystBuilder,
        ReactionPathwayAnalyzer,
    )
    HAS_APPLICATION_CASES = True
except ImportError as e:
    HAS_APPLICATION_CASES = False
    import warnings
    warnings.warn(f"Application cases not available: {e}")

# Add Advanced MD exports if available
if HAS_ADVANCED_MD:
    __all__.extend([
        # Enhanced Sampling
        'UmbrellaSamplingConfig',
        'MetadynamicsConfig',
        'REMDConfig',
        'TADConfig',
        'CollectiveVariable',
        'DistanceCV',
        'AngleCV',
        'DihedralCV',
        'CoordinationNumberCV',
        'UmbrellaSampling',
        'Metadynamics',
        'REMD',
        'TemperatureAcceleratedDynamics',
        'estimate_free_energy_barrier',
        'compute_error_pmf',
        
        # Free Energy
        'FEPConfig',
        'TIConfig',
        'BARConfig',
        'WHAMConfig',
        'FreeEnergyPerturbation',
        'ThermodynamicIntegration',
        'BennettAcceptanceRatio',
        'WHAM',
        'MBAR',
        'FreeEnergyAnalyzer',
        'compute_solvation_free_energy',
        'compute_binding_free_energy',
        
        # Rare Events
        'NEBConfig',
        'StringMethodConfig',
        'DimerConfig',
        'TSTConfig',
        'NEB',
        'StringMethod',
        'DimerMethod',
        'TransitionStateTheory',
        'find_mep_from_ts',
        'compute_activation_entropy',
        
        # Reaction Analysis
        'ReactionPathSearchConfig',
        'ReactionCoordinateConfig',
        'RateConstantConfig',
        'KMCConfig',
        'ReactionPathSearcher',
        'ReactionCoordinate',
        'RateConstantCalculator',
        'KMCPreprocessor',
        'ReactionNetwork',
    ])

# Add Advanced MD Analysis exports if available
if HAS_ADVANCED_MD_ANALYSIS:
    __all__.extend([
        'DynamicHeterogeneityConfig',
        'DynamicHeterogeneityAnalyzer',
        'StructuralAnalysisConfig',
        'RingStatistics',
        'VoronoiAnalysis',
        'BondOrientationalOrder',
        'CommonNeighborAnalysis',
        'StructuralAnalyzer',
        'CorrelationConfig',
        'TimeCorrelationAnalyzer',
        'VelocityAutocorrelation',
        'StressAutocorrelation',
        'DipoleAutocorrelation',
        'IntermediateScattering',
        'CorrelationAnalysisSuite',
    ])

# Add MLIP Training exports if available
if HAS_MLIP_TRAINING:
    __all__.extend([
        'MLIPType',
        'UnifiedTrainingConfig',
        'PredictionResult',
        'BaseMLIP',
        'UnifiedMLIPTrainer',
        'UnifiedMLIPCalculator',
        'quick_train',
        'load_model',
        'MACEDataConfig',
        'MACEArchitectureConfig',
        'MACETrainingConfig',
        'MACERunConfig',
        'MACEDatasetPreparer',
        'MACETrainer',
        'MACEEvaluator',
        'CHGNetDataConfig',
        'CHGNetArchitectureConfig',
        'CHGNetTrainingConfig',
        'CHGNetRunConfig',
        'CHGNetDatasetPreparer',
        'CHGNetTrainer',
        'CHGNetEvaluator',
        'OrbDataConfig',
        'OrbArchitectureConfig',
        'OrbTrainingConfig',
        'OrbRunConfig',
        'OrbDatasetPreparer',
        'OrbTrainer',
        'OrbEvaluator',
    ])

# Add Application Cases exports if available
if HAS_APPLICATION_CASES:
    __all__.extend([
        'IonMigrationConfig',
        'IonMigrationNEB',
        'MigrationPathAnalyzer',
        'PhaseTransitionConfig',
        'PhaseTransitionAnalyzer',
        'CatalyticReactionConfig',
        'CatalystBuilder',
        'ReactionPathwayAnalyzer',
    ])

# Topology imports (optional)
try:
    from .topology import (
        # Configuration
        Z2PackConfig,
        WannierToolsConfig,
        BerryPhaseConfig,
        
        # Enums
        TopologicalPhase,
        SymmetryType,
        SurfaceType,
        WeylChirality,
        PolarizationDirection,
        BerryCurvatureMethod,
        
        # Results
        WilsonLoopResult,
        Z2InvariantResult,
        ChernNumberResult,
        SurfaceStateResult,
        WeylPoint,
        WeylSearchResult,
        BandInversionResult,
        PolarizationResult,
        BerryCurvatureResult,
        AnomalousHallConductivityResult,
        
        # Main classes
        VASPWavefunctionExtractor,
        Z2VASPInterface,
        ChernNumberCalculator,
        TopologicalClassifier,
        Wannier90HamiltonianBuilder,
        WannierToolsCalculator,
        BandInversionAnalyzer,
        PolarizationCalculator,
        BerryCurvatureCalculator,
        AnomalousHallConductivityCalculator,
        
        # Convenience functions
        calculate_z2_index,
        calculate_chern_number,
        classify_topological_material,
        calculate_surface_states,
        search_weyl_points,
        analyze_band_inversion,
        calculate_polarization,
        calculate_berry_curvature,
        calculate_anomalous_hall_conductivity,
    )
    HAS_TOPOLOGY = True
except ImportError as e:
    HAS_TOPOLOGY = False
    import warnings
    warnings.warn(f"Topology module not available: {e}")

# Weyl semimetal imports (optional)
try:
    from .weyl import (
        # Configuration
        WeylSemimetalConfig,
        
        # Enums
        WeylType,
        FermiArcType,
        
        # Data classes
        WeylPointData,
        ChiralityResult,
        FermiArcData,
        MagnetotransportResult,
        
        # Calculators
        WeylPointLocator,
        ChiralityCalculator,
        FermiArcCalculator,
        MagnetotransportCalculator,
        
        # Convenience functions
        locate_weyl_points,
        calculate_fermi_arcs,
        analyze_weyl_semimetal,
    )
    HAS_WEYL = True
except ImportError as e:
    HAS_WEYL = False
    import warnings
    warnings.warn(f"Weyl semimetal module not available: {e}")

# Add Topology exports if available
if HAS_TOPOLOGY:
    __all__.extend([
        # Configuration
        'Z2PackConfig',
        'WannierToolsConfig',
        'BerryPhaseConfig',
        
        # Enums
        'TopologicalPhase',
        'SymmetryType',
        'SurfaceType',
        'WeylChirality',
        'PolarizationDirection',
        'BerryCurvatureMethod',
        
        # Results
        'WilsonLoopResult',
        'Z2InvariantResult',
        'ChernNumberResult',
        'SurfaceStateResult',
        'WeylPoint',
        'WeylSearchResult',
        'BandInversionResult',
        'PolarizationResult',
        'BerryCurvatureResult',
        'AnomalousHallConductivityResult',
        
        # Classes
        'VASPWavefunctionExtractor',
        'Z2VASPInterface',
        'ChernNumberCalculator',
        'TopologicalClassifier',
        'Wannier90HamiltonianBuilder',
        'WannierToolsCalculator',
        'BandInversionAnalyzer',
        'PolarizationCalculator',
        'BerryCurvatureCalculator',
        'AnomalousHallConductivityCalculator',
        
        # Functions
        'calculate_z2_index',
        'calculate_chern_number',
        'classify_topological_material',
        'calculate_surface_states',
        'search_weyl_points',
        'analyze_band_inversion',
        'calculate_polarization',
        'calculate_berry_curvature',
        'calculate_anomalous_hall_conductivity',
    ])

# Add Weyl exports if available
if HAS_WEYL:
    __all__.extend([
        'WeylSemimetalConfig',
        'WeylType',
        'FermiArcType',
        'WeylPointData',
        'ChiralityResult',
        'FermiArcData',
        'MagnetotransportResult',
        'WeylPointLocator',
        'ChiralityCalculator',
        'FermiArcCalculator',
        'MagnetotransportCalculator',
        'locate_weyl_points',
        'calculate_fermi_arcs',
        'analyze_weyl_semimetal',
    ])

# Strongly Correlated Systems imports (optional)
try:
    from .correlated import (
        # DMFT
        DMFTConfig,
        WannierProjectorConfig,
        DMFTEngine,
        CTQMCSolver,
        WannierProjector,
        VASPDMFTInterface,
        ImpuritySolver,
        
        # Hubbard U
        HubbardUConfig,
        LinearResponseU,
        ConstrainedRPA,
        SelfConsistentU,
        DFTPlusUOptimizer,
        UDatabase,
        calculate_u_eff,
        estimate_u_from_ionicity,
        check_u_reasonableness,
        
        # Utilities
        calculate_double_occupancy,
        calculate_kinetic_energy,
        estimate_nev_order_parameter,
        check_fermi_liquid,
        calculate_spectral_weight,
    )
    from .mott import (
        MottAnalysisConfig,
        GapAnalyzer,
        MetalInsulatorTransition,
        OrderParameterAnalyzer,
        estimate_mott_gap,
        calculate_u_critical_2d,
        calculate_u_critical_3d,
        analyze_quasiparticle_residue,
        estimate_brinkman_rice_z,
        check_luttinger_theorem,
    )
    HAS_CORRELATED = True
except ImportError as e:
    HAS_CORRELATED = False
    import warnings
    warnings.warn(f"Correlated systems module not available: {e}")

# Add Correlated Systems exports if available
if HAS_CORRELATED:
    __all__.extend([
        # DMFT
        'DMFTConfig',
        'WannierProjectorConfig',
        'DMFTEngine',
        'CTQMCSolver',
        'WannierProjector',
        'VASPDMFTInterface',
        'ImpuritySolver',
        
        # Hubbard U
        'HubbardUConfig',
        'LinearResponseU',
        'ConstrainedRPA',
        'SelfConsistentU',
        'DFTPlusUOptimizer',
        'UDatabase',
        'calculate_u_eff',
        'estimate_u_from_ionicity',
        'check_u_reasonableness',
        
        # Mott Insulators
        'MottAnalysisConfig',
        'GapAnalyzer',
        'MetalInsulatorTransition',
        'OrderParameterAnalyzer',
        'estimate_mott_gap',
        'calculate_u_critical_2d',
        'calculate_u_critical_3d',
        
        # Utilities
        'calculate_double_occupancy',
        'calculate_kinetic_energy',
        'estimate_nev_order_parameter',
        'check_fermi_liquid',
        'calculate_spectral_weight',
    ])

# Run dependency check on import
try:
    check_dependencies()
except ImportError as e:
    import warnings
    warnings.warn(str(e))
