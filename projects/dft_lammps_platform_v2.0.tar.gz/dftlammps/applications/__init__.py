"""
DFTLammps Excited State Applications Module
============================================
Practical applications of excited-state calculations:
- Solar cell optimization
- Quantum well LED design
- Color center quantum computing

Submodules:
- excited_state_applications: Device optimization and simulation

Example usage:
    from dftlammps.applications import SolarCellOptimizer
    from dftlammps.applications import QuantumWellLED
    from dftlammps.applications import ColorCenterQuantumComputing
"""

from .excited_state_applications import (
    SolarCellOptimizer,
    SolarCellParameters,
    QuantumWellLED,
    QuantumWellLEDParameters,
    ColorCenterQuantumComputing,
)

__all__ = [
    'SolarCellOptimizer',
    'SolarCellParameters',
    'QuantumWellLED',
    'QuantumWellLEDParameters',
    'ColorCenterQuantumComputing',
]

__version__ = '1.0.0'
